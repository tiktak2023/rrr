#!/usr/bin/python -tt
import pyodbc
from datetime import datetime
from dateutil import tz
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session
from sqlalchemy import create_engine
from sqlalchemy.exc import NoResultFound, IntegrityError
from list_id_instance import list_id_instance
import uuid


#select serverid_target  from gdat.dbo.SERVER_LINK sl where [type] = 'pdb'

Base = automap_base()
new_gdat = "postgresql://gdat:z9RykV3c(FsI0@gdat_dev_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb"
engine = create_engine(new_gdat)

Base.prepare(engine, reflect=True)
technical_component = Base.classes.technical_component
technical_data = Base.classes.technical_data

conn = pyodbc.connect(
    "DRIVER=FreeTDS;SERVER=gdtuatdb01.fr.world.socgen;PORT=11030;DATABASE=gdat;UID=X194770;PWD=Ifeb0ctt;TDS_Version=5.0;"
)

def get_name_db(serverid_source):
    with conn.cursor() as cur:
        req_sql = """select name from gdat.dbo.SERVER s where serverid={serverid_source} """
        res = cur.execute(req_sql)
        ret = res.fetchone()
        return ret

with conn.cursor() as cur:
    req_sql = f"""select serverid_target, serverid_source  from gdat.dbo.SERVER_LINK sl where [type] = 'pdb' """
    res = cur.execute(req_sql)
    total = res.fetchall()



# list_obj = []
# session =  Session(engine)
# total = [session.query(technical_component).filter_by(id=ids).one() for ids in list_id_instance]
FRA = tz.gettz("Europe/Paris")
list_obj = []
for row in total:
    serverid_target = row[0]
    serverid_source = row[1]
    session = Session(engine)
    obj = session.query(technical_component).filter_by(id=serverid_source).one()
    obj = session.query(technical_component).filter_by(parent_component_id=obj.uuid).one()
    last_modified = created_at = datetime.now().astimezone(tz=FRA)
    data_input = {}
    data_input["name_component"] = get_name_db(serverid_source)[0]
    print('data_input:', data_input)
    data_input["type_component_id"] = 25
    data_input["parent_component_id"] = obj.uuid
    res_uuid = getattr(uuid, "uuid4")
    data_input["uuid"] = res_uuid()
    data_input["last_modified"] = last_modified
    data_input["created_at"] = created_at
    data_input["modified_by"] = "AUTO"
    data_input["id"] = serverid_target
    obj = technical_component(**data_input)
    data_input.pop('uuid')
    data_input.pop('name_component')
    data_input.pop('type_component_id')
    data_input["component_uuid"] = data_input["uuid"]
    data_input["technical_key"] = "CDB"
    data_input["technical_value"] = "YES"



    obj1 = technical_data(**data_input)
    list_obj.append(obj)#Add ora_listener

session =  Session(engine)
print('len(list_obj)', len(list_obj))
#print('list_obj:', list_obj)
#exit(1)

for obj in list_obj:
    try:

        session.add(obj)
        session.commit()
    except Exception as e:
        #session =  Session(engine)
        #session.query(technical_component).filter_by(id=obj.id).delete()
        #session.commit()
        print('------Deleted------')
        print(e)
        print('------Deleted------')
        continue



