#!/usr/bin/python -tt
import pyodbc
from datetime import datetime
from dateutil import tz
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from sqlalchemy import create_engine
from sqlalchemy.exc import NoResultFound, IntegrityError
from list_source import list_source


Base = automap_base()
new_gdat = "postgresql://gdat:z9RykV3c(FsI0@gdat_dev_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb"
engine = create_engine(new_gdat)

Base.prepare(engine, reflect=True)
technical_component = Base.classes.technical_component


for item in list_source:
    session = Session(engine)
    obj = session.query(technical_component).filter_by(technical_component.id=item).one()
    app = obj.application_id
    obj = session.query(technical_component).filter_by(technical_component.parent_component_id=obj.uuid).one()
    if obj:
        session.query(technical_component).filter(technical_component.parent_component_id == obj.uuid).update()

    obj = session.query(technical_component).filter_by(technical_component.parent_component_id=obj.uuid).one()
    if obj:
        session.query(technical_component).filter(technical_component.parent_component_id == obj.uuid).update()
    






