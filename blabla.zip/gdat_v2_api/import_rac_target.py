#!/usr/bin/python -tt
import pyodbc
from datetime import datetime
from dateutil import tz
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from sqlalchemy import create_engine
from sqlalchemy.exc import NoResultFound, IntegrityError


Base = automap_base()
new_gdat = "postgresql://gdat:z9RykV3c(FsI0@gdat_dev_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb"
engine = create_engine(new_gdat)

Base.prepare(engine, reflect=True)
technical_component = Base.classes.technical_component
service = Base.classes.service
technical_data = Base.classes.technical_data

def return_name_service(service_id):
    with Session(engine) as session:
            try:
                obj_comp = session.query(service).filter_by(id=service_id).one()
                return obj_comp.service_name
            except NoResultFound:
                return None   




def get_list_uuid(list_id, type):
    list_uuid = []
    cpt = 0
    for id in list_id:
        try:
            with Session(engine) as session:
                obj = session.query(technical_component).filter_by(id=id).one()
                #clean_tdata(obj.uuid)
                obj_fils = session.query(technical_component).filter_by(parent_component_id=obj.uuid, type_component_id=type).one()
                
                clean_tdata(obj_fils.uuid)
                #session.query(technical_component).filter_by(parent_component_id=obj.uuid, type_component_id=type).delete()
                session.query(technical_component).filter_by(id=obj_fils.id, type_component_id=type).delete()
                session.commit()
                #list_uuid.append(obj_fils.uuid)
        except NoResultFound:
            cpt = cpt + 1
            list_uuid.append(cpt)
            continue
        except IntegrityError as e:
            clean_tdata(obj_fils.uuid)
            continue

    return list_uuid


def clean_comp(list_uuid):
    list_type_comp = [29, 27, 26, 24, 23]

    with Session(engine) as session:
        for uuid in list_uuid:
            for type in list_type_comp:
                try:
                    obj_comp_source = session.query(technical_component).filter_by(parent_component_id=uuid, type_component_id=type).one()
                    session.query(technical_component).filter_by(id=obj_comp_source.id).delete()
                    session.commit()
                except NoResultFound:
                    if type == 23:
                        try:
                            obj_comp_source = session.query(technical_component).filter_by(uuid=uuid, type_component_id=type).one()
                            session.query(technical_component).filter_by(id=obj_comp_source.id).delete()
                            session.commit()
                        except NoResultFound:
                            continue
                    else:
                        continue


def clean_tdata(uuid):
    with Session(engine) as session:
        try:
            session.query(technical_data).filter_by(component_uuid=uuid).delete()
            session.commit()
        except Exception as e:
            print('e:', e)
            return None


def clean_up_tech_data(list_id):
    list_uuid = []
    with Session(engine) as session:
        for uuid in list_id:
            try:
                obj_comp_target = session.query(technical_component).filter_by(component_uuid=uuid).one()
                if obj_comp_target:
                    list_uuid.append(obj_comp_target.uuid)
                    session.query(technical_data).filter_by(component_uuid=uuid).delete()
                    session.commit()
            except NoResultFound:
                continue

        return list_uuid








def manage_comp(source_id, target_id):
    with Session(engine) as session:
        dic = {}
        try:
            obj_comp_source = session.query(technical_component).filter_by(id=source_id, type_component_id=23).one()
            parent_component_id = obj_comp_source.uuid
            dic[target_id] = parent_component_id
        except NoResultFound:
                return dic
        return dic

conn = pyodbc.connect(
    "DRIVER=FreeTDS;SERVER=gdtuatdb01.fr.world.socgen;PORT=11030;DATABASE=gdat;UID=X194770;PWD=Ifeb0ctt;TDS_Version=5.0;"
)
list_obj = []
list_target = []
oradb = False
with conn.cursor() as cur:
        req_sql = f"""SELECT  serverid as id FROM dbo.SERVER as s where vendor='oracle' and type='cluster' """
        res = cur.execute(req_sql)
        total = res.fetchall()
        print("len(total):", len(total))
        for row in total:
            id = row[0]
            req_sql = f"""select serverid_source, serverid_target  from gdat.dbo.SERVER_LINK sl where serverid_source = {id} """
            res = cur.execute(req_sql)
            total = res.fetchall()
            for row in total:
                list_target.append(row[1])
            #list_target = [row[1] for row in total]
        
        list_target = tuple(list_target)
        print('list_target:', list_target)
    #     req_sql = f"""SELECT uuid4, xaas as arch_id,
    #                              msp as management_type, purpose as env, name as name_compponent_ora_system, vendor as type_component,
    #                              version as component_version, hostid as primary_host_id,
    #                              serviceid as service_id, serverid as id, oradbname as name_component_ora_database, instance as name_component_ora_instance FROM dbo.SERVER as s
    #                              where  serverid in {list_target}"""
    #
    #     res = cur.execute(req_sql)
    #     total = res.fetchall()
    #
    #     print(len(total))
    #     for row in total:
    #         id = row[9]
    #         req_sql = f"""select serverid_source, serverid_target  from gdat.dbo.SERVER_LINK sl where serverid_target = {id} """
    #         res = cur.execute(req_sql)
    #         ret = res.fetchone()
    #         print('res:', ret)
    #         dic = manage_comp(ret[0], ret[1])
    #         if dic == {} or dic is None:
    #             continue
    #         print('dic:', dic)
    #         for k, v in dic.items():
    #             server_id = k
    #             parent_component_id = v
    #         FRA = tz.gettz("Europe/Paris")
    #         last_modified = created_at = datetime.now().astimezone(tz=FRA)
    #         data_input = {}
    #         if not row[1]:
    #             data_input["arch_id"] = 20
    #         elif row[1] == 1:
    #             data_input["arch_id"] = 23
    #         elif row[1] == 2:
    #             data_input["arch_id"] = 1
    #         elif row[1] == 3:
    #             data_input["arch_id"] = 21
    #         elif row[1] == 4:
    #             data_input["arch_id"] = 22
    #         if row[2]:
    #             management_type_id = 8
    #         if "devel" in row[3]:
    #             data_input["env_component_id"] = 5
    #         if "prod" in row[3]:
    #             data_input["env_component_id"] = 7
    #
    #         if "dr" in row[3]:
    #             data_input["env_component_id"] = 19
    #         if "uat" in row[3]:
    #             data_input["env_component_id"] = 6
    #         #data_input["name_component"] = row[10] if row[10] else row[11]
    #         if not row[11] and return_name_service(row[8]):
    #             data_input["name_component"] =  return_name_service(row[8])
    #
    #         elif row[11]:
    #             data_input["name_component"] = row[11]
    #         else:
    #             continue
    #
    #         #data_input["name_component"] = row[11]
    #         data_input["id"] = row[9]
    #         data_input["type_component_id"] = 26
    #         data_input["parent_component_id"] = parent_component_id
    #         data_input["component_version"] = row[6]
    #         data_input["primary_host_id"] = row[7]
    #         data_input["service_id"] = row[8] if row[8] else None
    #         data_input["last_modified"] = datetime.now().astimezone(tz=FRA)
    #         data_input["created_at"] = datetime.now().astimezone(tz=FRA)
    #         if not row[0]:
    #             import uuid
    #
    #             res_uuid = getattr(uuid, "uuid4")
    #             row[0] = res_uuid()
    #         data_input["uuid"] = row[0]
    #         data_input["modified_by"] = "TAKAUTOSOURCE"
    #         #obj = return_comp(row[0])
    #         #if obj:
    #          #   list_obj.append(obj.uuid)#Add ora_system
    #
    #         obj = technical_component(**data_input) #Add ora_systeme
    #         list_obj.append(obj)#Add ora_system
    # #ret =  session.query(technical_component).all()
    #
    #         import uuid
    #         data_input.pop('id')
    #         service_name =  return_name_service(row[8])
    #
    #         if service_name:
    #             data_input["name_component"] = service_name
    #             data_input["type_component_id"] = 27
    #             data_input["parent_component_id"] = data_input["uuid"]
    #             res_uuid = getattr(uuid, "uuid4")
    #             data_input["uuid"] = res_uuid()
    #             obj = technical_component(**data_input)
    #             list_obj.append(obj)#Add ora_listener
    #
    #     session =  Session(engine)
    #     print('len(list_obj)', len(list_obj))
    #     #print('list_obj:', list_obj)
    #     for obj in list_obj:
    #         try:
    #             session.add(obj)
    #             session.commit()
    #         except Exception as e:
    #             from pprint import pprint
    #             pprint(obj.__dict__)
    #             print(e)
    #             #session =  Session(engine)
    #             #session.query(technical_component).filter_by(id=obj.id).delete()
    #             #session.commit()
    #             print('------Deleted------')
    #             print(e)
    #             print('------Deleted------')
    #             continue
