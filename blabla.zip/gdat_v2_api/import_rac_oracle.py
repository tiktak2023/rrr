#!/usr/bin/python -tt
import pyodbc
from datetime import datetime
from dateutil import tz
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session
from sqlalchemy import create_engine
from sqlalchemy.exc import NoResultFound, IntegrityError
from list_id_instance import list_id_instance


Base = automap_base()
new_gdat = "postgresql://gdat:z9RykV3c(FsI0@gdat_dev_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb"
engine = create_engine(new_gdat)

Base.prepare(engine, reflect=True)
technical_component = Base.classes.technical_component
service = Base.classes.service



session =  Session(engine)



total = [session.query(technical_component).filter_by(id=ids) for ids in list_id_instance]
FRA = tz.gettz("Europe/Paris")
print('len(total):', len(total))
for row in total:
    ret = session.query(technical_component).filter_by(parent_component_id=obj.id).one()
    last_modified = created_at = datetime.now().astimezone(tz=FRA)
    data_input = {}
    data_input["name_component"] = service_name
    data_input["type_component_id"] = 27
    data_input["parent_component_id"] = data_input["uuid"]
    res_uuid = getattr(uuid, "uuid4")
    data_input["uuid"] = res_uuid()
    obj = technical_component(**data_input)
    list_obj.append(obj)#Add ora_listener

session =  Session(engine)
print('len(list_obj)', len(list_obj))
#print('list_obj:', list_obj)
#exit(1)
for obj in list_obj:
    try:
        session.add(obj)
        session.commit()
    except Exception as e:
        #session =  Session(engine)
        #session.query(technical_component).filter_by(id=obj.id).delete()
        #session.commit()
        print('------Deleted------')
        print(e)
        print('------Deleted------')
        continue


def return_name_service(service_id):
    with Session(engine) as session:
            try:
                obj_comp = session.query(service).filter_by(id=service_id).one()
                return obj_com.name
            except NoResultFound:
                return None    
