#!/usr/bin/python -tt
import pyodbc
from datetime import datetime
from dateutil import tz
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from sqlalchemy import create_engine
from sqlalchemy.exc import NoResultFound, IntegrityError


Base = automap_base()
new_gdat = "postgresql://gdat:z9RykV3c(FsI0@gdat_dev_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb"
engine = create_engine(new_gdat)

Base.prepare(engine, reflect=True)
technical_component = Base.classes.technical_component
service = Base.classes.service
technical_data = Base.classes.technical_data

def return_parent(comp_id):
    with Session(engine) as session:
            try:
                obj_comp = session.query(technical_component).filter_by(id=comp_id).one()
                return obj_comp.uuid
            except NoResultFound:
                return None   

 
conn = pyodbc.connect(
    "DRIVER=FreeTDS;SERVER=gdtuatdb01.fr.world.socgen;PORT=11030;DATABASE=gdat;UID=X194770;PWD=Ifeb0ctt;TDS_Version=5.0;"
)
list_obj = []
list_tech_data = []
with conn.cursor() as cur:

        req_sql = f"""SELECT uuid4, xaas as arch_id,
                            msp as management_type,
                            purpose as env,
                            name as name_compponent,
                            version as component_version,
                            hostid as primary_host_id,
                            serviceid as service_id,
                            serverid as id,
                            port,  status FROM dbo.SERVER as s where vendor='datastax' and type='cssndra'
                            and serverid in (SELECT serverid_target  from dbo.SERVER_LINK sl )"""

        res = cur.execute(req_sql)
        total = res.fetchall()
        print('len(total):', len(total))
        FRA = tz.gettz("Europe/Paris")
        print('len(total):', len(total))
        for row in total:
            source_id = row[8]
            req_sql = f""" SELECT source_target  from dbo.SERVER_LINK sl where  serverid_source={source_id}"""
            res = cur.execute(req_sql)
            ret = res.fetchone()
            print('ret:', ret)
            paret_comp_id = return_parent(ret)
            if not paret_comp_id:
                continue
            print('paret_comp_id:', paret_comp_id)
            exit(1)
            last_modified = created_at = datetime.now().astimezone(tz=FRA)
            data_input = {}
            if not row[1]:
                data_input["arch_id"] = 20
            elif row[1] == 1:
                data_input["arch_id"] = 23
            elif row[1] == 2:
                data_input["arch_id"] = 1
            elif row[1] == 3:
                data_input["arch_id"] = 21
            elif row[1] == 4:
                data_input["arch_id"] = 22
            if row[2]:
                management_type_id = 8
            if "devel" in row[3]:
                data_input["env_component_id"] = 5
            if "prod" in row[3]:
                data_input["env_component_id"] = 7
            if "dr" in row[3]:
                data_input["env_component_id"] = 19
            if "uat" in row[3]:
                data_input["env_component_id"] = 6
            #data_input["name_component"] = row[10] if row[10] else row[11]
            data_input["name_component"] = row[4]
            data_input["id"] = row[8]
            data_input["type_component_id"] = 19
            data_input["parent_component_id"] = paret_comp_id
            data_input["component_version"] = row[5]
            data_input["primary_host_id"] = row[6]
            data_input["service_id"] = row[7] if row[7] else None
            data_input['status_id'] = row[10] if row[10] else None
            data_input["last_modified"] = datetime.now().astimezone(tz=FRA)
            data_input["created_at"] = datetime.now().astimezone(tz=FRA)
            if not row[0]:
                import uuid

                res_uuid = getattr(uuid, "uuid4")
                row[0] = res_uuid()
            data_input["uuid"] = row[0]
            data_input["modified_by"] = "AUTOTAKCASS"
            obj = technical_component(**data_input)
            list_obj.append(obj)
            if row[9]:
                tech_data = {'component_uuid': row[0], 'technical_key': 'port', 'technical_value':row[9], 'modified_by':data_input["modified_by"], 'last_modified':last_modified}
                obj = technical_data(**tech_data)
                list_tech_data.append(obj)
            
                         
        session =  Session(engine)
        #print('len(list_obj)', len(list_obj))
        print('len(list_tech_data)', len(list_tech_data))
        
#        for obj in list_obj:
#            try:
#                session.add(obj)
#                session.commit()
#            except Exception as e:
#                print(e)
#                continue

        for obj in list_tech_data:
            try:
                session.add(obj)
                session.commit()
            except Exception as e:
                print(e)
                continue


