#!/usr/bin/python -tt
import pyodbc
from datetime import datetime
from dateutil import tz
from sqlalchemy import create_engine
from sqlalchemy.exc import NoResultFound, IntegrityError, MultipleResultsFound
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session

Base = automap_base()
new_gdat = "postgresql://gdat:c0BWMD5Eld,kyJM5Gl8@gdat_prod_db-gdt_5932_prd.fr.world.socgen:12400/gdatdb"

engine = create_engine(new_gdat)

Base.prepare(engine, reflect=True)
technical_component = Base.classes.technical_component
technical_data = Base.classes.technical_data
services = Base.classes.service
hosts = Base.classes.hosts
users = Base.classes.users
applications = Base.classes.applications


def check_users(user):
    session = Session(engine)
    if user:
        try:
            obj = session.query(users).filter_by(id=user).one()
            return obj.id
            session.close()
        except NoResultFound as e:
            print('user1 not found:', user)
            session.close()
            return None


def check_iapplicode(data):
    if '-' in data:
        irt, trg = data.split('-')
        return irt, trg

    return int(data)


def get_id_mssql():
    session = Session(engine)
    list_id = session.query(technical_component).filter_by(type_component_id=5).all()
    session.close()
    list_id = [obj.id for obj in list_id]
    list_id = tuple(list_id)
    return list_id


conn = pyodbc.connect(
    "DRIVER=FreeTDS;SERVER=gdtuatdb01.fr.world.socgen;PORT=11030;DATABASE=gdat;UID=X194770;PWD=Ifeb0ctt;TDS_Version=5.0;"
)

iapplicode, irt, trg = None, None, None
list_multi = []
list_not_found = []
with conn.cursor() as cur:
    list_id = get_id_mssql()
    req_sql = f
    """ SELECT iappliid, dbaid, dbabkpid1, dbabkpid2, s.serverid
                       from SERVER s
                        inner join [OBJECT] o on s.serverid = o.serverid
                        inner join dbo.PROJECT_OBJECT po on po.objectid = o.objectid
                        inner join dbo.PROJECT p  on po.projectid = p.projectid
                        WHERE s.serverid in {list_id} and iappliid is not null"""

    res = cur.execute(req_sql)
    total = res.fetchall()
    for row in total:
        user1 = check_users(row[1])
        user2 = check_users(row[2])
        user3 = check_users(row[3])
        ret = check_iapplicode(row[0])
        if isinstance(ret, 'int'):
            iapplicode = ret
        else:
            irt, trg = ret[0], ret[1]

        session = Session(engine)
        if iapplicode:
            try:
                ret = session.query(applications).filter_by(iapplicode=str(iapplicode)).one()
                session.close()
            except NoResultFound as e:
                list_not_found.append(iapplicode)
                session.close()
                continue

            except MultipleResultsFound:
                list_multi.append(iapplicode)
                session.close()
                continue


        else:
            try:
                ret = session.query(applications).filter_by(irt=irt).filter_by(trigram=trg).one()
                session.close()
            except NoResultFound as e:
                session.close()
                continue

        data_update = {'application_id': ret.uuid, 'dba1': user1, 'dba2': user2, 'dba3': user3}
        session = Session(engine)
        session.query(technical_component).filter_by(id=row[4]).update(data_update)
        session.commit()
    print('Multiple applications:', list_multi)
    print('NoResultFound applications:', list_not_found)
