#!/usr/bin/python -tt
import pyodbc
from datetime import datetime
from dateutil import tz
from sqlalchemy import create_engine
from sqlalchemy.exc import NoResultFound, IntegrityError
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session

Base = automap_base()
new_gdat = "postgresql://gdat:c0BWMD5Eld,kyJM5Gl8@gdat_prod_db-gdt_5932_prd.fr.world.socgen:12400/gdatdb"

engine = create_engine(new_gdat)

Base.prepare(engine, reflect=True)
technical_component = Base.classes.technical_component
technical_data = Base.classes.technical_data
services = Base.classes.service
hosts = Base.classes.hosts


def check_service(ids):
    try:
        session = Session(engine)
        ret = session.query(services).filter_by(id=ids).one()
        session.close()
        return ret
    except NoResultFound:
        return None


def check_hosts(ids):
    try:
        session = Session(engine)
        ret = session.query(hosts).filter_by(id=ids).one()
        session.close()
        return ret
    except NoResultFound:
        return None


conn = pyodbc.connect(
    "DRIVER=FreeTDS;SERVER=gdtuatdb01.fr.world.socgen;PORT=11030;DATABASE=gdat;UID=X194770;PWD=Ifeb0ctt;TDS_Version=5.0;"
)
list_obj = []
list_obj_dt = []
list_service_not_found_mssql = []
list_hosts_not_found_mssql = []


def delete_td(obj):
    session = Session(engine)
    session.query(technical_data).filter_by(component_uuid=obj.uuid).delete()
    session.commit()


def delete(ids, cpt):
    try:
        session = Session(engine)
        ret = session.query(technical_component).filter_by(id=ids).one()
        session.close()
        delete_td(ret)
        session = Session(engine)
        session.query(technical_component).filter_by(id=ids).delete()
        session.commit()
    except NoResultFound as e:
        print('NoResultFound:', e)
        session.close()
        return None
    except IntegrityError as e:
        print('IntegrityError:', e)
        session = Session(engine)
        cpt = cpt + 1
        ret_children = session.query(technical_component).filter_by(parent_component_id=ret.uuid).all()
        print('ret_children:', ret_children)
        session.close()
        for obj in ret_children:
            delete(obj.id, cpt=cpt)
            # session = Session(engine)
            # session.query(technical_component).filter_by(id=obj.id).delete()
            # session.commit()

        session = Session(engine)
        session.query(technical_component).filter_by(id=ret.id).delete()
        session.commit()

        session.query(technical_component).filter_by(id=ret.parent_component_id).delete()
        session.commit()


def get_id_mssql():
    session = Session(engine)
    list_id = session.query(technical_component).filter_by(type_component_id=5).all()
    session.close()
    list_id = [obj.id for obj in list_id]
    list_id = tuple(list_id)
    return list_id


list_ids = []
list_instance_0 = []
service_0 = False
host_not_found = ''
list_name_id_not_added = []
with conn.cursor() as cur:
    list_id = get_id_mssql()
    print('len list_id:', len(list_id))
    exit(1)
    req_sql = f
    """SELECT
            s.uuid4,
            s.xaas as arch_id,
            s.msp as management_type,
            s.purpose as env,
            s.name as name_compponent,
            s.version as component_version,
            s.hostid as primary_host_id,
            s.serviceid as service_id,
            s.serverid as id,
            s.ebf,
            s.charset,
            s.reserverd_vol,
            s.allocated_vol,
            s.used_vol,
            s.port,
            s2.name,
            s2.domainname
            FROM dbo.SERVER as s, dbo.SERVICE s2
            where s.vendor='mssql' and s.[type] ='server' and s.serviceid = s2.serviceid and s.serverid not in {list_id}"""

    res = cur.execute(req_sql)
    total = res.fetchall()
    FRA = tz.gettz("Europe/Paris")
    print('len(total):', len(total))
    for row in total:
        if row[7]:
            try:
                session = Session(engine)
                session.query(services).filter_by(id=row[7]).one()
                session.close()
            except NoResultFound:
                # list_service_not_found_mssql.append(row[7])
                session.close()
                service_name = row[15] + '.' + row[16]
                last_modified = created_at = datetime.now().astimezone(tz=FRA)
                service_input = {'id': row[7], 'service_name': service_name,
                                 'active': True, 'created_at': datetime.now().astimezone(tz=FRA),
                                 'modified_at': datetime.now().astimezone(tz=FRA),
                                 'modified_by': '02022023service_not_found'}
                obj = services(**service_input)
                try:
                    session = Session(engine)
                    session.add(obj)
                    session.commit()
                except IntegrityError:
                    session.close()
                    session = Session(engine)
                    res = session.query(services).filter_by(service_name=service_name).one()
                    session.close()
                    row[7] = res.id

        if row[7] == 0:
            service_0 = True
            row[7] = None
            list_instance_0.append(row[8])

        try:
            session = Session(engine)
            ret = session.query(hosts).filter_by(id=row[6]).one()
            session.close()
        except NoResultFound:
            list_hosts_not_found_mssql.append((row[6], row[4]))
            host_not_found = str(row[6])
            row[6] = None
            session.close()

        cpt = 0
        delete(row[8], cpt=cpt)
        last_modified = created_at = datetime.now().astimezone(tz=FRA)
        data_input = {}
        if not row[0]:
            import uuid

            res_uuid = getattr(uuid, "uuid4")
            row[0] = res_uuid()

        if not row[1]:
            data_input["arch_id"] = 20
        elif row[1] == 1:
            data_input["arch_id"] = 23
        elif row[1] == 2:
            data_input["arch_id"] = 1
        elif row[1] == 3:
            data_input["arch_id"] = 21
        elif row[1] == 4:
            data_input["arch_id"] = 22

        if row[2]:
            management_type_id = 8  # doit etre mis à jour à 8

        if "devel" in row[3]:
            data_input["env_component_id"] = 5
        if "prod" in row[3]:
            data_input["env_component_id"] = 7
        if "dr" in row[3]:
            data_input["env_component_id"] = 19
        if "uat" in row[3]:
            data_input["env_component_id"] = 6

        # data_input["name_component"] = row[10] if row[10] else row[11]
        data_input["name_component"] = row[4]
        data_input["id"] = row[8]
        data_input["type_component_id"] = 5
        data_input["component_version"] = row[5]
        data_input["primary_host_id"] = row[6]
        data_input["ebf"] = row[9]
        data_input["service_id"] = row[7]
        data_input["last_modified"] = datetime.now().astimezone(tz=FRA)
        data_input["created_at"] = datetime.now().astimezone(tz=FRA)
        data_input["uuid"] = row[0]
        if service_0:
            data_input["modified_by"] = "3101202317:44mssql_with_service_0"
        else:
            data_input["modified_by"] = "3101202317:44mssql"

        obj = technical_component(**data_input)  # Add mssql
        list_ids.append(obj.id)
        list_obj.append(obj)  # Add mssql

        if row[14]:
            data_input = {}
            data_input["last_modified"] = datetime.now().astimezone(tz=FRA)
            data_input["modified_by"] = datetime.now().astimezone(tz=FRA)
            data_input["component_uuid"] = row[0]
            data_input["technical_key"] = 'port'
            data_input["technical_value"] = row[14]
            obj = technical_data(**data_input)  # Add mssql port
            list_obj_dt.append(obj)  # Add mssql port

        if row[11]:
            data_input = {}
            data_input["last_modified"] = datetime.now().astimezone(tz=FRA)
            data_input["modified_by"] = datetime.now().astimezone(tz=FRA)
            data_input["component_uuid"] = row[0]
            data_input["technical_key"] = 'reserved_vol'
            data_input["technical_value"] = row[11]
            obj = technical_data(**data_input)  # Add mssql reserved_vol
            list_obj_dt.append(obj)  # Add mssql reserved_vol

        if row[13]:
            data_input = {}
            data_input["last_modified"] = datetime.now().astimezone(tz=FRA)
            data_input["modified_by"] = datetime.now().astimezone(tz=FRA)
            data_input["component_uuid"] = row[0]
            data_input["technical_key"] = 'used_vol'
            data_input["technical_value"] = row[13]
            obj = technical_data(**data_input)  # Add mssql used_vol
            list_obj_dt.append(obj)  # Add mssql used_vol

        if row[12]:
            data_input = {}
            data_input["last_modified"] = datetime.now().astimezone(tz=FRA)
            data_input["modified_by"] = datetime.now().astimezone(tz=FRA)
            data_input["component_uuid"] = row[0]
            data_input["technical_key"] = 'allocated_vol'
            data_input["technical_value"] = row[12]
            obj = technical_data(**data_input)  # Add mssql allocated_vol
            list_obj_dt.append(obj)  # Add mssql allocated_vol

        if row[10]:
            data_input = {}
            data_input["last_modified"] = datetime.now().astimezone(tz=FRA)
            data_input["modified_by"] = datetime.now().astimezone(tz=FRA)
            data_input["component_uuid"] = row[0]
            data_input["technical_key"] = 'charset'
            data_input["technical_value"] = row[10]
            obj = technical_data(**data_input)  # Add mssql charset
            list_obj_dt.append(obj)  # Add mssql charset

    print('list_name_id_not_added:', list_name_id_not_added)
    print('len of new list_ids:', len(list_ids))
    # print('len of new service_not_found_mssql:', len(list_service_not_found_mssql))
    print('len of new hosts_not_found_mssql:', len(list_hosts_not_found_mssql))
    print('list_hosts_not_found_mssql:', list_hosts_not_found_mssql)
    # print('service_not_found_mssql:', list_service_not_found_mssql)
    # list_instance_0
    print('service_not_found_mssql with 0:', list_instance_0)
    print('len service_not_found_mssql with 0:', len(list_instance_0))

    print('list new:', list_ids)

    session = Session(engine)
    session.bulk_save_objects(list_obj)
    session.commit()

    session = Session(engine)
    session.bulk_save_objects(list_obj_dt)
    session.commit()







    # """SELECT dbo.SERVER.name as component_name,
    #           dbo.HOST.name as host_name,
    #           dbo.SERVICE.name as service_name,
    #           dbo.SERVER.[type],dbo.SERVER.[vendor],
    #           dbo.SERVER.purpose ,dbo.SERVER.uuid4 ,
    #           dbo.SERVER.msp ,dbo.SERVER.xaas,
    #           dbo.SERVER.version + ' ' + dbo.SERVER.ebf as version dbo.SERVER.serverid,
    #           dbo.[OBJECT].objectid,
    #           dbo.[OBJECT].[type],
    #           dbo.PROJECT.name as project_name,
    #           dbo.PROJECT.iappliid,
    #           dbo.PROJECT.trg FROM dbo.SERVER INNER JOIN dbo.[OBJECT]
    #           on dbo.SERVER.serverid = dbo.[OBJECT].serverid INNER JOIN dbo.PROJECT_OBJECT on dbo.PROJECT_OBJECT.objectid = dbo.[OBJECT].objectid INNER JOIN dbo.PROJECT on dbo.PROJECT.projectid = dbo.PROJECT_OBJECT.projectid INNER JOIN dbo.HOST on dbo.HOST.hostid = dbo.SERVER.hostid INNER JOIN dbo.SERVICE
    #           on dbo.SERVICE.serviceid = dbo.SERVER.serviceid  WHERE dbo.[OBJECT].[type] = 'server' """
