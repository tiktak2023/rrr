#!/usr/bin/python -tt
import pyodbc
from datetime import datetime
from dateutil import tz
from sqlalchemy import create_engine
from sqlalchemy.exc import NoResultFound, IntegrityError, MultipleResultsFound
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session

Base = automap_base()
new_gdat = "postgresql://gdat:c0BWMD5Eld,kyJM5Gl8@gdat_prod_db-gdt_5932_prd.fr.world.socgen:12400/gdatdb"

engine = create_engine(new_gdat)

Base.prepare(engine, reflect=True)
technical_component = Base.classes.technical_component
technical_data = Base.classes.technical_data
services = Base.classes.service
hosts = Base.classes.hosts
service_host = Base.classes.service_host


def get_all_host_service(type_component):
    session = Session(engine)
    ret = session.query(technical_component).filter_by(type_component_id=5).all()
    session.close()
    ret = [(obj.service_id, obj.primary_host_id) for obj in ret]
    return ret


def update_service_host(data):
    list_id = []
    session = Session(engine)
    for dt in data:
        try:
            session.query(service_host).filter_by(id_service=dt[0]).filter_by(host_id=dt[1]).one()
        except NoResultFound:
            service_input = {'id_service': dt[0],
                             'id_host': dt[1],
                             'type_host': 17
                             }
            obj = service_host(**service_input)
            session.add(obj)
            session.commit()
            list_id.append(obj.id)
        except MultipleResultsFound:
            continue
    print('list id service:', list_id)


if __name__ == '__main__':
    res = get_all_host_service(5)
    update_service_host(res)
