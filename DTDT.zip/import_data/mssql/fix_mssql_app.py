#!/usr/bin/python -tt
import pyodbc
from datetime import datetime
from dateutil import tz
from sqlalchemy import create_engine
from sqlalchemy.exc import NoResultFound, IntegrityError
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session

Base = automap_base()
# new_gdat = "postgresql://gdat:c0BWMD5Eld,kyJM5Gl8@gdat_prod_db-gdt_5932_prd.fr.world.socgen:12400/gdatdb"
new_gdat = 'postgresql://gdat:z9RykV3c(FsI0@gdat_dev_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb'

engine = create_engine(new_gdat)

Base.prepare(engine, reflect=True)
technical_component = Base.classes.technical_component
technical_data = Base.classes.technical_data
services = Base.classes.service
hosts = Base.classes.hosts


def get_uuid_application(data):
    iapplicode = False
    if not '-' in str(data):
        if isinstance(int(data), int):
            iapplicode = data
    else:
        data = data.split('-')
        irt, trg = data[0], data[1]

    # session = Session(engine)
    if iapplicode:
        try:
            session = Session(engine)
            ret = (
                session.query(applications).filter_by(iapplicode=str(iapplicode)).one()
            )
            session.close()
            return ret.uuid
        except NoResultFound as e:
            list_app.append(iapplicode)
            # list_not_found.append(iapplicode)
            session.close()
            return

        except MultipleResultsFound:
            list_app_multiple.append(iapplicode)
            session = Session(engine)
            ret = (
                session.query(applications).filter_by(iapplicode=str(iapplicode)).all()
            )
            session.close()
            return ret[0].uuid
            # list_multi.append(iapplicode)
    else:
        try:
            session = Session(engine)
            ret = (
                session.query(applications)
                    .filter_by(irt=irt)
                    .filter_by(trigram=trg)
                    .one()
            )
            session.close()
            return ret.uuid
        except NoResultFound as e:
            session.close()
            return
        except MultipleResultsFound as e:
            session = Session(engine)
            ret = (
                session.query(applications)
                    .filter_by(irt=irt)
                    .filter_by(trigram=trg)
                    .all()
            )
            session.close()
            return ret[0].uuid
            # list_not_found.append(iapplicode)


conn = pyodbc.connect(
    "DRIVER=FreeTDS;SERVER=gdtuatdb01.fr.world.socgen;PORT=11030;DATABASE=gdat;UID=X194770;PWD=Ifeb0ctt;TDS_Version=5.0;"
)


def get_id_mssql():
    session = Session(engine)
    list_id = session.query(technical_component).filter_by(type_component_id=5).all()
    session.close()
    list_id = [obj.id for obj in list_id]
    list_id = tuple(list_id)
    return list_id


list_ids = []
list_instance_0 = []
service_0 = False
host_not_found = ''
list_name_id_not_added = []
req_sql = f
"""SELECT
	    s.serverid as id,
	    p.iappliid
	    FROM dbo.SERVER as s
		inner join [OBJECT] o on s.serverid = o.serverid
		inner join dbo.PROJECT_OBJECT po on po.objectid = o.objectid
		inner join dbo.PROJECT p  on po.projectid = p.projectid
		where p.iappliid is not null
	    and s.vendor='mssql' and s.[type] ='server' """

with conn.cursor() as cur:
    list_id = get_id_mssql()
    print('len list_id:', len(list_id))
    req_sql = req_sql + 'and s.serverid  in {list_id} '
    res = cur.execute(req_sql)
    total = res.fetchall()
    FRA = tz.gettz("Europe/Paris")
    for row in total:
        app_uuid = get_uuid_application(row[1])
        session = Session(engine)
        session.query(technical_component).filter_by(id=row[0]).update({'application_id': app_uuid})
        session.commit()
