#!/usr/bin/python -tt
import pyodbc
from datetime import datetime
from dateutil import tz
from sqlalchemy import create_engine
from sqlalchemy.exc import NoResultFound, IntegrityError
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session

Base = automap_base()
new_gdat = "postgresql://gdat:c0BWMD5Eld,kyJM5Gl8@gdat_prod_db-gdt_5932_prd.fr.world.socgen:12400/gdatdb"

engine = create_engine(new_gdat)

Base.prepare(engine, reflect=True)
technical_component = Base.classes.technical_component
technical_data = Base.classes.technical_data
services = Base.classes.service
hosts = Base.classes.hosts

conn = pyodbc.connect(
    "DRIVER=FreeTDS;SERVER=gdtuatdb01.fr.world.socgen;PORT=11030;DATABASE=gdat;UID=X194770;PWD=Ifeb0ctt;TDS_Version=5.0;"
)
list_obj = []
list_obj_dt = []
list_service_not_found_mssql = []
list_hosts_not_found_mssql = []

obj = None
with conn.cursor() as cur:
    req_sql = f
    """SELECT s.serverid, h.name
            FROM dbo.SERVER as s, dbo.HOST h
            where s.vendor='mssql' and s.[type] ='server' and s.hostid = h.hostid and s.serviceid = 0"""

    res = cur.execute(req_sql)
    total = res.fetchall()
    FRA = tz.gettz("Europe/Paris")
    print('len(total):', len(total))
    for row in total:
        session = Session(engine)
        try:
            obj = session.query(services).filter_by(service_name=row[1]).one()
            session.close()
        except NoResultFound as e:
            print('errror not found:', e)
            session.close()
            service_input = {'service_name': row[1],
                             'active': True, 'created_at': datetime.now().astimezone(tz=FRA),
                             'modified_at': datetime.now().astimezone(tz=FRA),
                             'modified_by': '02022023service_0_MAJ'}
            obj = services(**service_input)
            session = Session(engine)
            session.add(obj)
            session.commit()
        # try:
        #     session = Session(engine)
        #     session.add(obj)
        #     session.commit()
        # except IntegrityError as e:
        #     print('e:-------->', e)
        #     session.close()
        #     session = Session(engine)
        #     obj = session.query(services).filter_by(service_name=row[1]).one()
        #     session.close()

        data_maj = {"service_id": obj.id,
                    "last_modified": datetime.now().astimezone(tz=FRA),
                    "modified_by": "ls"}
        session = Session(engine)
        session.query(technical_component).filter_by(id=row[0]).update(data_maj)
        session.commit()
