#!/usr/bin/python -tt
import pyodbc
from datetime import datetime
from dateutil import tz
from sqlalchemy import create_engine
from sqlalchemy.exc import IntegrityError
from sqlalchemy.exc import NoResultFound
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session

Base = automap_base()
new_gdat = "postgresql://gdat:z9RykV3c(FsI0@gdat_dev_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb"
engine = create_engine(new_gdat)

Base.prepare(engine, reflect=True)
technical_component = Base.classes.technical_component
technical_data = Base.classes.technical_data
service = Base.classes.service

# print("list_val:-----------'", list_items)


conn = pyodbc.connect(
    "DRIVER=FreeTDS;SERVER=gdtuatdb01.fr.world.socgen;PORT=11030;DATABASE=gdat;UID=X194770;PWD=Ifeb0ctt;TDS_Version=5.0;"
)


def return_name_service(service_id):
    with Session(engine) as session:
        try:
            obj_comp = session.query(service).filter_by(id=service_id).one()
            return obj_comp.service_name
        except NoResultFound:
            return None


with conn.cursor() as cur:
    session = Session(engine)
    obj_all = session.query(technical_component).filter(technical_component.type_component_id == 23).filter(
        technical_component.service_id is None).all()
    for obj in obj_all:
        id = obj.id
        req_sql = f
        """SELECT serviceid as service_id FROM dbo.SERVER as s where serverid={id}  """
        res = cur.execute(req_sql)
        total = res.fetchone()
        print("len total 1:", len(total))
        service_id = total[0]
        ret = return_name_service(service_id)
        if ret:
            ser_update = {'service_id': service_id}
            obj_23 = session.query(technical_component).filter(technical_component.id == id).one()
            obj_24 = session.query(technical_component).filter(
                technical_component.parent_compoent_id == obj_23.uuid).one()
            obj_26 = session.query(technical_component).filter(
                technical_component.parent_compoent_id == obj_24.uuid).one()
            session.query(technical_component).filter(technical_component.id == obj_26.id).update(ser_update)
            session.query(technical_component).filter(technical_component.parent_compoent_id == obj_26.uuid).update(
                ser_update)
