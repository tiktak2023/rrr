#!/usr/bin/python -tt
import pyodbc
from datetime import datetime
from dateutil import tz
from sqlalchemy import create_engine
from sqlalchemy.exc import IntegrityError, MultipleResultsFound
from sqlalchemy.exc import NoResultFound, IntegrityError
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session

Base = automap_base()
# new_gdat = "postgresql://gdat:,X7SD_QFpg3a?5Sh@gdat_uat_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb"
# new_gdat = 'postgresql://gdat:z9RykV3c(FsI0@gdat_dev_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb'
new_gdat = "postgresql://gdat:c0BWMD5Eld,kyJM5Gl8@gdat_prod_db-gdt_5932_prd.fr.world.socgen:12400/gdatdb"

engine = create_engine(new_gdat, pool_size=20, max_overflow=0)

Base.prepare(engine, reflect=True)
technical_component = Base.classes.technical_component
service = Base.classes.service
applications = Base.classes.application
users = Base.classes.users
technical_data = Base.classes.technical_data
services = Base.classes.service
hosts = Base.classes.hosts
service_host = Base.classes.service_host


def add_new_key_value(obj, key, type, value):
    FRA = tz.gettz("Europe/Paris")
    if obj.type_component_id == type:
        session = Session(engine)
        ora_db_name_obj = session.query(technical_component).filter_by(parent_component_id=obj.uuid).one()
        session.close()
        if ora_db_name_obj.type_component_id == 24:
            print('added ora_db_name_obj.name:', ora_db_name_obj.name)
            data_input = {}
            data_input["last_modified"] = datetime.now().astimezone(tz=FRA)
            data_input["modified_by"] = value + 'standalone_oracle'
            data_input["component_uuid"] = ora_db_name_obj.uuid
            data_input["technical_key"] = key
            data_input["technical_value"] = value
            obj = technical_data(**data_input)
            return obj


def add_new_key_values(obj, key, type, value):
    FRA = tz.gettz("Europe/Paris")

    if obj.type_component_id == type:
        print('added ora_db_name_obj.name:', obj.name_component)
        data_input = {}
        data_input["last_modified"] = datetime.now().astimezone(tz=FRA)
        data_input["modified_by"] = value + 'standalone_oracle'
        data_input["component_uuid"] = obj.uuid
        data_input["technical_key"] = key
        data_input["technical_value"] = value
        obj = technical_data(**data_input)
        return obj


if __name__ == "__main__":
    session = Session(engine)
    list_tech_data = []
    search = "%{}%".format('dtg_')
    stand_obj_all = session.query(technical_component).filter_by(type_component_id=26). \
        filter(technical_component.modified_by.like(search)).all()

    name_comp = [obj.name_component for obj in stand_obj_all]
    print('name_comp:', name_comp)
    for obj in stand_obj_all:
        ret = add_new_key_values(obj, key='ora_instance_name', type=26, value=obj.name_component)
        list_tech_data.append(ret)

    session = Session(engine)
    session.bulk_save_objects(list_tech_data)
    session.commit()
