#!/usr/bin/python -tt
import pyodbc
from datetime import datetime
from dateutil import tz
from sqlalchemy import create_engine
from sqlalchemy.exc import IntegrityError, MultipleResultsFound
from sqlalchemy.exc import NoResultFound, IntegrityError
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session

Base = automap_base()
# new_gdat = "postgresql://gdat:,X7SD_QFpg3a?5Sh@gdat_uat_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb"
# new_gdat = "postgresql://gdat:c0BWMD5Eld,kyJM5Gl8@gdat_prod_db-gdt_5932_prd.fr.world.socgen:12400/gdatdb"
new_gdat = 'postgresql://gdat:z9RykV3c(FsI0@gdat_dev_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb'

engine = create_engine(new_gdat, pool_size=20, max_overflow=0)

Base.prepare(engine, reflect=True)
technical_component = Base.classes.technical_component
service = Base.classes.service
applications = Base.classes.application
users = Base.classes.users
technical_data = Base.classes.technical_data
services = Base.classes.service
hosts = Base.classes.hosts
service_host = Base.classes.service_host


# result = session.query(Category.category_id, Category.name) \
#     .filter(
#         Category.name.in_(("Action", "Horror",  "Sci-Fi"))
# )

# def data_to_update(type_component):
#     session = Session(engine)
#     ret = {'silo_id':1, 'life_cycle_status_id':2, 'status_id': 3}
#     session.query(technical_component).filter_by(id=73703).update(ret)
#     session.commit()
#     list_data = session.query(technical_component).filter_by(type_component_id=type_component).filter_by(id=45558).all()
#     for item in list_data:
#
#     list_data_updated = [{'silo_id':obj.silo_id, 'life_cycle_status_id':obj.life_cycle_status_id, 'status_id': obj.status_id}
#                          for obj in list_data]
#     return list_data_updated
#
#
# def cascade(data, tuple_component_id):
#     session = Session(engine)
#     for item in data:
#         session.query(technical_component).filter(technical_component.type_component_id.in_(tuple_component_id)).update(item)


def cascade(types_father):
    # '%ocp_dba%'
    search = "%{}%".format('rac')
    FRA = tz.gettz("Europe/Paris")
    val = str(datetime.now().astimezone(tz=FRA)) + 'rac'
    for type in types_father:
        session = Session(engine)
        ret_all = session.query(technical_component).filter_by(type_component_id=type). \
            filter(technical_component.modified_by.like(search)).all()
        for obj in ret_all:
            ret = {'silo_id': obj.silo_id,
                   'life_cycle_status_id': obj.life_cycle_status_id,
                   'status_id': obj.status_id,
                   'dba1': obj.dba1,
                   'dba2': obj.dba2,
                   'dba3': obj.dba3,
                   'modified_by': val}
            session.query(technical_component).filter_by(parent_component_id=obj.uuid).update(ret)
            session.commit()


def cascade_xaas(types_father):
    for type in types_father:
        session = Session(engine)
        ret_all = session.query(technical_component).filter_by(type_component_id=type). \
            filter_by(modified_by='TAKAUTO13022023standalone_oracle').all()
        for obj in ret_all:
            ret = {'arch_id': obj.arch_id}
            session.query(technical_component).filter_by(parent_component_id=obj.uuid).update(ret)
            session.commit()


# TAKAUTO13022023standalone_oracle

if __name__ == "__main__":
    cascade([23, 24, 26])
