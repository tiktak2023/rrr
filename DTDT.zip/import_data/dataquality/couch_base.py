#!/usr/bin/python -tt
import pyodbc
from datetime import datetime
from dateutil import tz
from sqlalchemy import create_engine
from sqlalchemy.exc import IntegrityError, MultipleResultsFound
from sqlalchemy.exc import NoResultFound, IntegrityError
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session

Base = automap_base()
# new_gdat = "postgresql://gdat:,X7SD_QFpg3a?5Sh@gdat_uat_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb"
new_gdat = 'postgresql://gdat:z9RykV3c(FsI0@gdat_dev_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb'

engine = create_engine(new_gdat, pool_size=20, max_overflow=0)

Base.prepare(engine, reflect=True)
technical_component = Base.classes.technical_component

FRA = tz.gettz("Europe/Paris")


def manage_dataquality(type_comp):
    session = Session(engine)
    all_server = session.query(technical_component).filter_by(type_component_id=type_comp).all()
    session.close()
    for server in all_server:
        update_data = {'env_component_id': server.env_component_id,
                       'application_id': server.application_id,
                       'modified_by': str(datetime.now().astimezone(tz=FRA)) + 'DataqualitycouchBase'}
        session = Session(engine)
        session.query(technical_component).filter_by(uuid=server.parent_component_id).update(update_data)
        session.commit()


if __name__ == "__main__":
    # manage couch_base_dataquality
    manage_dataquality(21)
