#!/usr/bin/python -tt
import pyodbc
from datetime import datetime
from dateutil import tz
from sqlalchemy import create_engine
from sqlalchemy.exc import IntegrityError, MultipleResultsFound
from sqlalchemy.exc import NoResultFound, IntegrityError
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session

Base = automap_base()
# new_gdat = "postgresql://gdat:,X7SD_QFpg3a?5Sh@gdat_uat_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb"
new_gdat = 'postgresql://gdat:z9RykV3c(FsI0@gdat_dev_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb'

engine = create_engine(new_gdat, pool_size=20, max_overflow=0)

Base.prepare(engine, reflect=True)
technical_component = Base.classes.technical_component
service = Base.classes.service
applications = Base.classes.application
users = Base.classes.users
technical_data = Base.classes.technical_data
services = Base.classes.service
hosts = Base.classes.hosts
service_host = Base.classes.service_host

list_td_all = []

list_users_not_found = []

list_app_not_found = []
service_id = None
oradb_instance_created = False


def return_name_service(service_id):
    with Session(engine) as session:
        try:
            obj_comp = session.query(service).filter_by(id=service_id).one()
            return obj_comp.service_name
        except NoResultFound:
            return None


def check_service(service_data, name_service, name_domaine):
    if service_data:
        try:
            session = Session(engine)
            obj = session.query(services).filter_by(id=service_data).one()
            session.close()
            return obj.id
        except NoResultFound:
            # list_service_not_found_mssql.append(row[7])
            session.close()
            service_name = name_service + '.' + name_domaine
            # service_name = row[15] + '.' + row[16]
            last_modified = created_at = datetime.now().astimezone(tz=FRA)
            service_input = {'id': service_data, 'service_name': service_name,
                             'active': True, 'created_at': datetime.now().astimezone(tz=FRA),
                             'modified_at': datetime.now().astimezone(tz=FRA),
                             'modified_by': '03022023service_not_found'}
            obj = services(**service_input)
            session = Session(engine)
            session.add(obj)
            session.commit()
            return obj.id


def check_host_service(host_id, service_id):
    if host_id and service_id:
        try:
            session = Session(engine)
            obj = session.query(service_host).filter_by(id_service=service_id). \
                filter_by(id_host=host_id).one()
            session.close()
            return obj
        except NoResultFound:
            session.close()
            service_input = {"id_service": service_id, "id_host": host_id, "type_host": 17}
            obj = service_host(**service_input)
            session = Session(engine)
            session.add(obj)
            session.commit()
            return obj


# def check_host_service(host_id, service_id):
#     if host_id and service_id:
#         service_input = {'id_service': service_id,
#                          'id_host': host_id,
#                          'type_host': 17
#                          }
#         obj = service_host(**service_input)
#         session.add(obj)
#         session.commit()

def check_host(host_data):
    try:
        session = Session(engine)
        session.query(hosts).filter_by(id=host_data).one()
        session.close()
        return True
    except NoResultFound:
        session.close()
        return None


req_sql4 = f
"""SELECT s.serverid, h.name
	           FROM dbo.SERVER as s, dbo.HOST h   
	           where s.vendor='oracle' and s.[type] ='server' and s.hostid = h.hostid and s.serviceid = 0"""


def check_service_o0(total):
    for row in total:
        try:
            session = Session(engine)
            obj = session.query(services).filter_by(service_name=row[1]).one()
            session.close()
            print('service_id from found:', obj.id)
            return obj
        except NoResultFound as e:
            print('errror not found:', e)
            session.close()
            service_input = {'service_name': row[1],
                             'active': True, 'created_at': datetime.now().astimezone(tz=FRA),
                             'modified_at': datetime.now().astimezone(tz=FRA),
                             'modified_by': '02022023service_0_MAJRac'}
            obj = services(**service_input)
            session = Session(engine)
            try:
                session.add(obj)
                session.commit()
                print('service_id from not found:', obj.id)
                return obj
            except IntegrityError as e:
                print('e:----------->', e)
                print('total ---for service 0---->', total)
                session.close()
                print('serverid:', row[0])
                print('hostname:', row[1])


def insert_tech_data(asm,
                     oradbid,
                     nbconnection,
                     charset,
                     sid,
                     reserved_vol,
                     port,
                     db_unique_name,
                     used_vol,
                     obj_new_gdat):
    asm = "True" if asm else "False"  # 24 ko true fo 1 or 0 not ok
    oradbid = oradbid if oradbid else 0  # 23 ok
    nbconnection = nbconnection if nbconnection else 0  # 26 ko
    charset = charset if charset else ''  # 23 ok
    sid = sid if sid else ''  # 26 ko
    reserved_vol = reserved_vol if reserved_vol else 0  # 24 ko
    port = port  # 27 ko
    db_unique_name = db_unique_name if db_unique_name else ''  # 24 ko
    used_vol = used_vol if used_vol else 0  # 24 ko
    role = "primary"  # 24 ko

    list_key_24 = [
        ("asm", asm),
        ("reserved_vol", reserved_vol),
        ("db_unique_name", db_unique_name),
        ("used_vol", used_vol),
        ("role", role),
    ]
    list_key_23 = [("oradbid", oradbid), ("charset", charset), ("cdb", "True")]
    list_key_26 = [("nbconnection", nbconnection), ("sid", sid)]
    FRA = tz.gettz("Europe/Paris")
    list_objtd = []
    print('obj_new_gdat.type_component_id:', obj_new_gdat.type_component_id)
    if obj_new_gdat.type_component_id == 24:
        for item in list_key_24:
            data_input = {}
            data_input["last_modified"] = datetime.now().astimezone(tz=FRA)
            data_input["modified_by"] = "TAK15022023PDBORACLE"
            data_input["component_uuid"] = obj_new_gdat.uuid
            data_input["technical_key"] = item[0]
            data_input["technical_value"] = item[1]
            obj = technical_data(**data_input)
            list_objtd.append(obj)

    elif obj_new_gdat.type_component_id == 23:
        for item in list_key_23:
            data_input = {}
            data_input["last_modified"] = datetime.now().astimezone(tz=FRA)
            data_input["modified_by"] = "TAK15022023PDBORACLE"
            data_input["component_uuid"] = obj_new_gdat.uuid
            data_input["technical_key"] = item[0]
            data_input["technical_value"] = item[1]
            obj = technical_data(**data_input)
            list_objtd.append(obj)

    elif obj_new_gdat.type_component_id == 26:
        for item in list_key_26:
            data_input = {}
            data_input["last_modified"] = datetime.now().astimezone(tz=FRA)
            data_input["modified_by"] = "TAK15022023PDBORACLE"
            data_input["component_uuid"] = obj_new_gdat.uuid
            data_input["technical_key"] = item[0]
            data_input["technical_value"] = item[1]
            obj = technical_data(**data_input)
            list_objtd.append(obj)

    elif obj_new_gdat.type_component_id == 27:
        if port:
            data_input = {}
            data_input["last_modified"] = datetime.now().astimezone(tz=FRA)
            data_input["modified_by"] = "TAK15022023PDBORACLE"
            data_input["component_uuid"] = obj_new_gdat.uuid
            data_input["technical_key"] = "port"
            data_input["technical_value"] = port
            obj = technical_data(**data_input)
            list_objtd.append(obj)

    return list_objtd


req_sql = f
"""SELECT
   s.uuid4,
   s.xaas as arch_id,
   s.msp as management_type,
   s.purpose as env,
   s.name as name_compponent_ora_system,
   s.vendor as type_component,
   s.version as component_version,
   s.hostid as primary_host_id,
   s.serviceid as service_id,
   s.serverid as id,
   s.oradbname as name_component_ora_database,
   s.[instance] as name_component_ora_instance,
   s.ebf as ebf,
   s.serverid,
   s.reserverd_vol,
   s.allocated_vol,
   s.used_vol,
   s.port,
   s.oraasm as ASM, 
   s.oradbid as Oradbid, 
   s.charset,
   s.nbconnection
from SERVER s """

dic1 = {'charset': 20,
        'oradbid': 19,
        'oraasm': 18,
        'port': 17,
        'used_vol': 16,
        'allocated_vol': 15,
        'reserverd_vol': 14,
        'db_unique_name': 10,
        'sid': 11,
        'nbconnection': 21}

req_sql3 = f
""" SELECT
       s.uuid4, 
       s.xaas as arch_id,
       s.msp as management_type,
       s.purpose as env,
       s.name as name_compponent_ora_system,
       s.vendor as type_component,
       s.version as component_version,
       s.hostid as primary_host_id,
       s.serviceid as service_id,
       s.serverid as id,
       s.oradbname as name_component_ora_database,
       s.[instance] as name_component_ora_instance,
       s.ebf as ebf,
       s.serverid,
       p.iappliid,
       p.dbaid,
       p.dbabkpid1,
       p.dbabkpid2,
       s.charset,
       s.reserverd_vol,
       s.allocated_vol,
       s.used_vol,
       s.port,
       s.oraasm as ASM, 
       s.oradbid as Oradbid,
       s.nbconnection,
       s2.name,
       s2.domainname

from SERVER s
inner join dbo.SERVICE s2  on s.serviceid = s2.serviceid
inner join [OBJECT] o on s.serverid = o.serverid
inner join dbo.PROJECT_OBJECT po on po.objectid = o.objectid
inner join dbo.PROJECT p  on po.projectid = p.projectid
where p.iappliid is not null """

req_sql5 = f
""" SELECT
               s.uuid4, 
               s.xaas as arch_id,
               s.msp as management_type,
               s.purpose as env,
               s.name as name_compponent_ora_system,
               s.vendor as type_component,
               s.version as component_version,
               s.hostid as primary_host_id,
               s.serviceid as service_id,
               s.serverid as id,
               s.oradbname as name_component_ora_database,
               s.[instance] as name_component_ora_instance,
               s.ebf as ebf,
               s.serverid,
               p.iappliid,
               p.dbaid,
               p.dbabkpid1,
               p.dbabkpid2,
               s.charset,
               s.reserverd_vol,
               s.allocated_vol,
               s.used_vol,
               s.port,
               s.oraasm as ASM, 
               s.oradbid as Oradbid,
               s.nbconnection

            from SERVER s
            inner join [OBJECT] o on s.serverid = o.serverid
            inner join dbo.PROJECT_OBJECT po on po.objectid = o.objectid
            inner join dbo.PROJECT p  on po.projectid = p.projectid
            where p.iappliid is not null """

dic3 = {'charset': 20,
        'oradbid': 24,
        'oraasm': 23,
        'port': 22,
        'used_vol': 21,
        'allocated_vol': 20,
        'reserverd_vol': 19,
        'db_unique_name': 10,
        'sid': 11,
        'nbconnection': 25}

dic2 = {'charset': 20,
        'oradbid': 26,
        'oraasm': 25,
        'port': 24,
        'used_vol': 23,
        'allocated_vol': 22,
        'reserverd_vol': 21,
        'db_unique_name': 10,
        'sid': 11,
        'nbconnection': 27}


def check_iapplicode(data):
    if '-' in data:
        irt, trg = data.split('-')
        return irt, trg

    return int(data)


def check_users(user):
    session = Session(engine)
    if user:
        try:
            obj = session.query(users).filter_by(id=user).one()
            session.close()
            return obj.id
        except NoResultFound as e:
            print('user1 not found:', user)
            session.close()
            return None


def get_uuid_application(data):
    iapplicode = False
    if '-' not in str(data):
        if isinstance(int(data), int):
            iapplicode = data
    else:
        data = data.split('-')
        irt, trg = data[0], data[1]
        print('irt:--->', irt)
        print('trg:--->', trg)

    # session = Session(engine)
    if iapplicode:
        print('iapplicode:-------->', iapplicode)
        try:
            session = Session(engine)
            ret = session.query(applications).filter_by(iapplicode=str(iapplicode)).one()
            session.close()
            return ret.uuid
        except NoResultFound as e:
            # list_not_found.append(iapplicode)
            session.close()
            return

        except MultipleResultsFound:
            # list_multi.append(iapplicode)
            session.close()
            return
    else:
        try:
            session = Session(engine)
            ret = session.query(applications).filter_by(irt=irt).filter_by(trigram=trg).one()
            session.close()
            return ret.uuid
        except NoResultFound as e:
            session.close()
            return
        except MultipleResultsFound:
            # list_multi.append(iapplicode)
            session.close()
            return


conn = pyodbc.connect(
    "DRIVER=FreeTDS;SERVER=gdtuatdb01.fr.world.socgen;PORT=11030;DATABASE=gdat;UID=X194770;PWD=Ifeb0ctt;TDS_Version=5.0;"
)
list_obj = []
list_source = []
oradb = False
list_comp_not_inserted = []
list_with_one_ora = []
list_many_ora_inst = []
list_ora_db = []
with conn.cursor() as cur:
    # req_sql = """ SELECT uuid4, xaas as arch_id,
    #                   msp as management_type, purpose as env, name as name_compponent_ora_system, vendor as type_component,
    #                   version as component_version, hostid as primary_host_id,
    #                   serviceid as service_id, serverid as id, oradbname as name_component_ora_database,
    #                   instance as name_component_ora_instance FROM dbo.SERVER as s where vendor='oracle' and type='server' """

    # ret = f""" where  s.vendor='oracle' and s.type='cluster' and serverid=45558 and"""
    ret = f
    """ where  s.vendor='oracle' and s.type='cdb' and """
    res = f
    """ s.serverid in (select serverid_source  from gdat.dbo.SERVER_LINK sl) """
    req_sql1 = req_sql + ret + res
    print('req_sql1:', req_sql1)
    res = cur.execute(req_sql1)
    total = res.fetchall()
    FRA = tz.gettz("Europe/Paris")
    print('len(total):', len(total))
    list_id_comp = [row[9] for row in total]
    print('list_id_comp:', list_id_comp)
    for row in total:
        ora_pdb_cpt = 0
        # app_uuid = get_uuid_application(row[14])
        # user1 = check_users(row[1])
        # user2 = check_users(row[2])
        # user3 = check_users(row[3])
        #
        # if not user1 or not user2 or not user3 or not app_uuid:
        #     continue


        last_modified = created_at = datetime.now().astimezone(tz=FRA)
        data_input = {}
        # data_input['application_id'] = app_uuid
        # data_input['dba1'] = user1
        # data_input['dba2'] = user2
        # data_input['dba3'] = user3
        data_input["arch_id"] = 20
        data_input["management_type_id"] = 8
        # data_input["name_component"] = row[10] if row[10] else row[11]
        data_input["name_component"] = row[4]
        data_input["id"] = row[9]
        data_input["type_component_id"] = 23
        data_input["component_version"] = row[6]
        # data_input["primary_host_id"] = row[7]
        # data_input["service_id"] = row[8] if row[8] else None
        data_input["last_modified"] = datetime.now().astimezone(tz=FRA)
        data_input["created_at"] = datetime.now().astimezone(tz=FRA)
        if not row[0]:
            import uuid

            res_uuid = getattr(uuid, "uuid4")
            row[0] = res_uuid()
        data_input["uuid"] = row[0]
        data_input["modified_by"] = "TAKAUTO15022023pdb_oracle"
        # obj = return_comp(row[0])
        # if obj:
        #   list_obj.append(obj.uuid)#Add ora_system

        obj = technical_component(**data_input)  # Add ora_systeme
        session = Session(engine)
        session.add(obj)
        session.commit()
        # dic1 = {'charset': 20,
        #         'oradbid': 19,
        #         'oraasm': 18,
        #         'port': 17,
        #         'used_vol': 16,
        #         'allocated_vol': 15,
        #         'reserverd_vol': 14,
        #         'db_unique_name': 10,
        #         'sid': 11,
        #         'nbconnection': 21}

        dic3 = {'charset': 20,
                'oradbid': 24,
                'oraasm': 23,
                'port': 22,
                'used_vol': 21,
                'allocated_vol': 20,
                'reserverd_vol': 19,
                'db_unique_name': 10,
                'sid': 11,
                'nbconnection': 25}

        asm = row[18]
        oradbid = row[19]
        charset = row[20]
        sid = row[11]
        reserved_vol = row[14]
        port = row[17]
        db_unique_name = row[10]
        used_vol = row[16]
        allocated_vol = row[15]
        nbconnection = row[21]

        ltd_23 = insert_tech_data(asm=asm,
                                  oradbid=oradbid,
                                  nbconnection=nbconnection,
                                  charset=charset,
                                  sid=sid,
                                  reserved_vol=reserved_vol,
                                  port=port,
                                  db_unique_name=db_unique_name,
                                  used_vol=used_vol,
                                  obj_new_gdat=obj)
        list_td_all.append(ltd_23)

        # list_obj.append(obj)
        # ret =  session.query(technical_component).all()

        import uuid

        id = data_input['id']
        print('id:', id)
        data_input.pop('id')
        req_sql2 = f
        """select serverid_source, serverid_target  from gdat.dbo.SERVER_LINK sl
                                  where serverid_source={id}
                                  and serverid_target in (select serverid from  dbo.SERVER as s where vendor='oracle' and type='server')  """
        print('req_sql2:', req_sql2)
        res = cur.execute(req_sql2)
        total = res.fetchall()
        print('len total:', len(total))
        ora_database_created = False
        for row in total:
            oradb_instance_created = False
            ret = ''
            id_comp = row[1]
            # req_sql = f"""SELECT uuid4, xaas as arch_id,
            #              msp as management_type, purpose as env, name as name_compponent_ora_system, vendor as type_component,
            #              version as component_version, hostid as primary_host_id,
            #              serviceid as service_id, serverid as id, oradbname as name_component_ora_database,
            #              instance as name_component_ora_instance, ebf as ebf FROM dbo.SERVER as s where  serverid={id_comp}"""



            ret = f
            """ and s.serverid={id_comp} """
            req_sql = req_sql3 + ret
            print('req_sql 3 target:', req_sql)

            res = cur.execute(req_sql)
            total_db = res.fetchall()  # Total for dbname
            print('len(total):', len(total_db))
            if total_db:
                print('first res:', req_sql)
            req_sql = req_sql4 + ret
            res = cur.execute(req_sql)

            # print('req_sql4:----->', req_sql)
            total_s0 = res.fetchall()
            if total_s0:
                print('second res:', req_sql)

            print('total_s0:', total_s0)
            if not total_db and total_s0:
                if total_s0:
                    service_id = check_service_o0(total_s0)
                    print('service_id--------------->', service_id)
                    req_sql = req_sql5 + ret
                    res = cur.execute(req_sql)
                    print('req_sql5----------------->:', req_sql5)
                    total_db = res.fetchall()
                    if len(total_db) > 1:
                        total_db = total_db[0:1]
                        print('len(total_db) slice:', len(total_db))

                        print('total_db: slice', total_db)

                    # if len(total_db) != 1:
                    #     continue
                    print('total_db takk:', total_db)
                    print('service1:', total_db[0][8])
                    total_db[0][8] = service_id.id
                    new_service = True
                    list_ora_db.append(total_db[0])
                    db = total_db
                    print('db of service_0:', db)
                else:
                    print('why continue id comp:', id_comp)
                    continue

                    # req_sql5 = req_sql5 + ret
                    # res = cur.execute(req_sql5)
                    # print('req_sql5----------------->:', req_sql5)
                    # total_db = res.fetchall()
                    # if not total_db:
                    #     print('this server id like target not found:', id_comp)
                    #     continue

                    # req_sql4 = req_sql4 + ret
                    # res = cur.execute(req_sql4)
                    # total_s0 = res.fetchall()
                    # service_id = check_service_o0(total_s0)
                    # print("server_source, serverid_target bad !!", row[0], row[1])
            else:
                list_ora_db.append(total_db[0])
                db = total_db

            if len(total) == 1:
                list_with_one_ora.append(db[0][4])
            else:
                list_many_ora_inst.append(db[0][4])

            if total_db[0][10] and not ora_database_created:  # Find ora_database
                print('iappli total_db[0][14]', total_db[0][14])

                # if len(list_obj) < 1:
                app_uuid = get_uuid_application(db[0][14])
                user1 = check_users(total_db[0][15])
                user2 = check_users(total_db[0][16])
                user3 = check_users(total_db[0][17])

                if not user1 or not user2 or not user3 or not app_uuid:
                    if not user1:
                        list_users_not_found.append(total_db[0][15])
                    if not user2:
                        list_users_not_found.append(total_db[0][16])

                    if not user3:
                        list_users_not_found.append(total_db[0][17])

                    if not app_uuid:
                        list_app_not_found.append(total_db[0][14])

                    list_comp_not_inserted.append(id_comp)
                    # continue
                print('inserted comp:', id_comp)
                data_input['application_id'] = app_uuid
                data_input['dba1'] = user1
                data_input['dba2'] = user2
                data_input['dba3'] = user3

                ora_database_created = True
                data_input['id'] = total_db[0][9]
                data_input["name_component"] = total_db[0][10]
                data_input["type_component_id"] = 24
                data_input["component_version"] = total_db[0][6]
                data_input["arch_id"] = 20
                data_input["management_type_id"] = 8

                data_input["ebf"] = total_db[0][12]
                data_input["parent_component_id"] = data_input["uuid"]
                res_uuid = getattr(uuid, "uuid4")
                data_input["uuid"] = res_uuid()
                uuid_father = data_input["uuid"]
                if "devel" in total_db[0][3]:
                    data_input["env_component_id"] = 5
                if "prod" in total_db[0][3]:
                    data_input["env_component_id"] = 7

                if "dr" in total_db[0][3]:
                    data_input["env_component_id"] = 19
                if "uat" in total_db[0][3]:
                    data_input["env_component_id"] = 6

                obj = technical_component(**data_input)
                print('obj inserted affiché une seule fois:', obj.id)
                # dic2 = {'charset': 20,
                #         'oradbid': 26,
                #         'oraasm': 25,
                #         'port': 24,
                #         'used_vol': 23,
                #         'allocated_vol': 22,
                #         'reserverd_vol': 21,
                #         'db_unique_name': 10,
                #         'sid': 11,
                #         'nbconnection': 27}

                dic3 = {'charset': 20,
                        'oradbid': 24,
                        'oraasm': 23,
                        'port': 22,
                        'used_vol': 21,
                        'allocated_vol': 20,
                        'reserverd_vol': 19,
                        'db_unique_name': 10,
                        'sid': 11,
                        'nbconnection': 25}

                asm = total_db[0][23]
                oradbid = total_db[0][24]
                charset = total_db[0][20]
                sid = total_db[0][11]
                reserved_vol = total_db[0][19]
                port = total_db[0][22]
                db_unique_name = total_db[0][10]
                used_vol = total_db[0][21]
                allocated_vol = total_db[0][20]
                nbconnection = total_db[0][25]

                ltd_24 = insert_tech_data(asm=asm,
                                          oradbid=oradbid,
                                          nbconnection=nbconnection,
                                          charset=charset,
                                          sid=sid,
                                          reserved_vol=reserved_vol,
                                          port=port,
                                          db_unique_name=db_unique_name,
                                          used_vol=used_vol,
                                          obj_new_gdat=obj)
                # ltd_24 = insert_tech_data(db[0], obj)
                list_td_all.append(ltd_24)
                oradb = True
                list_obj.append(obj)  # Add ora_database
                env_updated = {'env_component_id': data_input["env_component_id"],
                               'component_version': data_input['component_version'],
                               'ebf': data_input['ebf'],
                               'dba1': user1,
                               'dba2': user2,
                               'dba3': user3,
                               'application_id': app_uuid}
                session = Session(engine)
                session.query(technical_component).filter(technical_component.id == row[0]).update(env_updated)
                session.commit()
                # data_input.pop('id')

            print('longuer list_ora_db:', len(list_ora_db))
            print('content list_ora_db:', list_ora_db)
            cpt = 0

            # Find the instance
            if 'id' in data_input:
                data_input.pop('id')
            # print('row from db:', row)
            # print('len(row from db):'+str(cpt), len(row))

            # if service_id:
            #     row[8] = service_id
            if len(total_db[0]) > 26:
                ## Creation du service si l n existe pas dans le new gdat
                service_id = check_service(total_db[0][8], total_db[0][26], total_db[0][27])

            check_host_service(total_db[0][7],
                               total_db[0][8])  # Creation d une entrée host/service si elle n existe pas

            # print('ret------>'+str(cpt), ret)

            # else:
            #     service_id = service_id.service_name
            # host_id = check_host(row[7])
            # print('tak host_id value:' + str(cpt), row[7])
            # print('tak host_id:'+str(cpt), host_id)
            # print('tak service_id:'+str(cpt), service_id)
            # check_host_service(row[7], row[8])
            # if host_id and service_id:
            #     ret = check_host_service(row[7], service_id)
            #     print('check host service:', ret)
            # check_host_service(row[7], service_id)

            if total_db[0][4]:
                session = Session(engine)
                ret = session.query(service_host).filter_by(id_service=total_db[0][8]). \
                    filter_by(id_host=total_db[0][7]).all()
                session.close()
                ret = ret[0]
                data_input["name_component"] = total_db[0][4]
                data_input["primary_host_id"] = ret.id_host
                data_input["type_component_id"] = 25
                data_input["parent_component_id"] = uuid_father
                # data_input["primary_host_id"] = total_db[7]
                # data_input["service_id"] = row[8] if not service_id else service_id
                data_input["service_id"] = ret.id_service
                uuid_father = data_input["parent_component_id"]
                res_uuid = getattr(uuid, "uuid4")
                data_input["uuid"] = res_uuid()
                obj = technical_component(**data_input)
                list_obj.append(obj)
                ora_pdb_cpt = ora_pdb_cpt + 1

            if total_db[0][11] and ora_pdb_cpt < 2:
                data_input["name_component"] = total_db[0][11]
                data_input["primary_host_id"] = ret.id_host
                data_input["type_component_id"] = 26
                data_input["parent_component_id"] = uuid_father
                data_input["service_id"] = ret.id_service

                # data_input["primary_host_id"] = row[7]

                res_uuid = getattr(uuid, "uuid4")
                data_input["uuid"] = res_uuid()
                obj = technical_component(**data_input)
                ltd_26 = insert_tech_data(asm=asm,
                                          oradbid=oradbid,
                                          nbconnection=nbconnection,
                                          charset=charset,
                                          sid=sid,
                                          reserved_vol=reserved_vol,
                                          port=port,
                                          db_unique_name=db_unique_name,
                                          used_vol=used_vol,
                                          obj_new_gdat=obj)
                list_td_all.append(ltd_26)
                print('data_input:' + str(cpt) + ':--->:', data_input)
                list_obj.append(obj)  # Add ora_instance
                # oradb_instance_created = True

                # if service_name:
                service_name = return_name_service(total_db[0][8])

                data_input["name_component"] = service_name if service_name else 'default'
                data_input["type_component_id"] = 27
                data_input["parent_component_id"] = data_input["uuid"]
                data_input["primary_host_id"] = ret.id_host
                data_input["service_id"] = ret.id_service
                res_uuid = getattr(uuid, "uuid4")
                data_input["uuid"] = res_uuid()
                obj = technical_component(**data_input)
                ltd_27 = insert_tech_data(asm=asm,
                                          oradbid=oradbid,
                                          nbconnection=nbconnection,
                                          charset=charset,
                                          sid=sid,
                                          reserved_vol=reserved_vol,
                                          port=port,
                                          db_unique_name=db_unique_name,
                                          used_vol=used_vol,
                                          obj_new_gdat=obj)
                list_td_all.append(ltd_27)
                list_obj.append(obj)  # Add ora_listener
                cpt = cpt + 1

    print('longuer de la liste ajouté: clem', len(list_obj))
    print(' liste ajouté:', list_obj)
    session = Session(engine)
    session.bulk_save_objects(list_obj)
    session.commit()

    list_tds_all = [j for i in list_td_all for j in i]

    session = Session(engine)
    session.bulk_save_objects(list_tds_all)
    session.commit()
    print('list_with_one_ora ----------->:', list_with_one_ora)
    print('list_many_ora_inst ----------->:', list_many_ora_inst)
    print('list_comp_not_inserted--------->:', list_comp_not_inserted)
    print('list_users_not_found:--------->', list_users_not_found)
    print('list_app_not_found:------------->', list_app_not_found)
