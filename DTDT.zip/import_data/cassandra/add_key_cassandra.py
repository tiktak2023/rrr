#!/usr/bin/python -tt
import pyodbc
from datetime import datetime
from dateutil import tz
from sqlalchemy import create_engine
from sqlalchemy.exc import NoResultFound, IntegrityError
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session

Base = automap_base()
# new_gdat = "postgresql://gdat:c0BWMD5Eld,kyJM5Gl8@gdat_prod_db-gdt_5932_prd.fr.world.socgen:12400/gdatdb"
new_gdat = 'postgresql://gdat:z9RykV3c(FsI0@gdat_dev_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb'

engine = create_engine(new_gdat)

Base.prepare(engine, reflect=True)
technical_component = Base.classes.technical_component
technical_data = Base.classes.technical_data
services = Base.classes.service
hosts = Base.classes.hosts


def check_service(ids):
    try:
        session = Session(engine)
        ret = session.query(services).filter_by(id=ids).one()
        session.close()
        return ret
    except NoResultFound:
        return None


def check_hosts(ids):
    try:
        session = Session(engine)
        ret = session.query(hosts).filter_by(id=ids).one()
        session.close()
        return ret
    except NoResultFound:
        return None


conn = pyodbc.connect(
    "DRIVER=FreeTDS;SERVER=gdtuatdb01.fr.world.socgen;PORT=11030;DATABASE=gdat;UID=X194770;PWD=Ifeb0ctt;TDS_Version=5.0;"
)
list_obj = []
list_obj_dt = []
list_service_not_found_mssql = []
list_hosts_not_found_mssql = []


def get_id_mssql():
    session = Session(engine)
    list_id = session.query(technical_component).filter_by(type_component_id=19).all()
    session.close()
    list_id = [obj.id for obj in list_id]
    list_id = tuple(list_id)
    return list_id


def get_uuid_mssql():
    session = Session(engine)
    list_id = session.query(technical_component).filter_by(type_component_id=5).all()
    session.close()
    list_id = [obj.uuid for obj in list_id]
    list_id = tuple(list_id)
    return list_id


list_ids = []
list_instance_0 = []
service_0 = False
host_not_found = ''
list_name_id_not_added = []
with conn.cursor() as cur:
    list_id = get_id_mssql()

    req_sql = f
    """select
       serverid,
       port
       FROM gdat.dbo.SERVER
       where serverid  in {list_id} and port is not NULL"""

    res = cur.execute(req_sql)
    total = res.fetchall()
    FRA = tz.gettz("Europe/Paris")
    print('len(total):', len(total))
    for row in total:
        session = Session(engine)
        obj = session.query(technical_component).filter_by(id=row[0]).one()
        data_input = {}
        data_input["last_modified"] = datetime.now().astimezone(tz=FRA)
        data_input["modified_by"] = str(datetime.now().astimezone(tz=FRA)) + 'port'
        data_input["component_uuid"] = obj.uuid
        data_input["technical_key"] = 'port'
        data_input["technical_value"] = row[1]
        obj = technical_data(**data_input)
        list_obj_dt.append(obj)

    session = Session(engine)
    session.bulk_save_objects(list_obj_dt)
    session.commit()
