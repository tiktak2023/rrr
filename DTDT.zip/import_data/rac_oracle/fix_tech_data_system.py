#!/usr/bin/python -tt
import pyodbc
from datetime import datetime
from dateutil import tz
from sqlalchemy import create_engine
from sqlalchemy.exc import IntegrityError, MultipleResultsFound
from sqlalchemy.exc import NoResultFound, IntegrityError
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session

Base = automap_base()
# new_gdat = "postgresql://gdat:,X7SD_QFpg3a?5Sh@gdat_uat_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb"
new_gdat = 'postgresql://gdat:z9RykV3c(FsI0@gdat_dev_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb'

engine = create_engine(new_gdat, pool_size=20, max_overflow=0)

Base.prepare(engine, reflect=True)
technical_component = Base.classes.technical_component
service = Base.classes.service
applications = Base.classes.application
users = Base.classes.users
technical_data = Base.classes.technical_data
services = Base.classes.service
hosts = Base.classes.hosts
service_host = Base.classes.service_host

req_sql = f
"""SELECT
   s.serverid,
   s.oradbid as Oradbid, 
   s.charset
   from SERVER s """

conn = pyodbc.connect(
    "DRIVER=FreeTDS;SERVER=gdtuatdb01.fr.world.socgen;PORT=11030;DATABASE=gdat;UID=X194770;PWD=Ifeb0ctt;TDS_Version=5.0;"
)

with conn.cursor() as cur:
    # req_sql = """ SELECT uuid4, xaas as arch_id,
    #                   msp as management_type, purpose as env, name as name_compponent_ora_system, vendor as type_component,
    #                   version as component_version, hostid as primary_host_id,
    #                   serviceid as service_id, serverid as id, oradbname as name_component_ora_database,
    #                   instance as name_component_ora_instance FROM dbo.SERVER as s where vendor='oracle' and type='server' """

    # ret = f""" where  s.vendor='oracle' and s.type='cluster' and serverid=45558 and"""
    ret = f
    """ where  s.vendor='oracle' and s.type !='cluster'  and"""
    res = f
    """ s.serverid in (select serverid_target  from gdat.dbo.SERVER_LINK sl where sl.type='cluster') """
    res1 = f
    """ and s.serverid not in (select serverid_target  from gdat.dbo.SERVER_LINK sl where sl.type='pdb') """
    req_sql1 = req_sql + ret + res + res1
    print('req_sql1:', req_sql1)
    res = cur.execute(req_sql1)
    total = res.fetchall()
    FRA = tz.gettz("Europe/Paris")
    print('len(total):', len(total))
    list_id_comp = [row[0] for row in total]
    print('list_id_comp:', list_id_comp)
    for row in total:
        oradbid = row[1]
        charset = row[2]
        charset_dic = {'technical_value': charset, 'modified_by': 'TAKA27022023rac_oracle_charset'}
        orabid_dic = {'technical_value': oradbid, 'modified_by': 'TAKA27022023rac_oracle_oradbid'}
        try:
            session = Session(engine)
            ret = session.query(technical_component).filter_by(id=row[0]).filter_by(type_component_id=24).one()
        except NoResultFound:
            session.close()
            continue

        if ret.name_component == 'PECSP0CS':
            print('row:', row)
        uuid = ret.parent_component_id
        if charset:
            ret = session.query(technical_data).filter_by(component_uuid=uuid).filter_by(
                technical_key='charset').update(charset_dic)
            session.commit()

        session.close()

        try:
            session = Session(engine)
            ret = session.query(technical_component).filter_by(id=row[0]).filter_by(type_component_id=24).one()
        except NoResultFound:
            session.close()
            continue

        uuid = ret.parent_component_id
        if oradbid:
            ret = session.query(technical_data).filter_by(component_uuid=uuid).filter_by(
                technical_key='oradbid').update(orabid_dic)
            session.commit()

        session.close()
