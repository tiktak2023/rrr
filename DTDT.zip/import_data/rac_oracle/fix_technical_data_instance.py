#!/usr/bin/python -tt
import pyodbc
from datetime import datetime
from dateutil import tz
from sqlalchemy import create_engine
from sqlalchemy.exc import IntegrityError, MultipleResultsFound
from sqlalchemy.exc import NoResultFound, IntegrityError
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session

Base = automap_base()
# new_gdat = "postgresql://gdat:,X7SD_QFpg3a?5Sh@gdat_uat_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb"
new_gdat = 'postgresql://gdat:z9RykV3c(FsI0@gdat_dev_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb'

engine = create_engine(new_gdat, pool_size=20, max_overflow=0)

Base.prepare(engine, reflect=True)
technical_component = Base.classes.technical_component
service = Base.classes.service
applications = Base.classes.application
users = Base.classes.users
technical_data = Base.classes.technical_data
services = Base.classes.service
hosts = Base.classes.hosts
service_host = Base.classes.service_host

if __name__ == "__main__":
    session = Session(engine)
    search = "%{}%".format('rac_oracle')
    stand_obj_all = session.query(technical_component).filter_by(type_component_id=26). \
        filter(technical_component.modified_by.like(search)).all()
    session.close()
    name_comp = [obj.name_component for obj in stand_obj_all]
    print('name_comp:', name_comp)
    for obj in stand_obj_all:
        session = Session(engine)
        updated = {'technical_value': obj.name_component}
        session.query(technical_data).filter_by(component_uuid=obj.uuid).filter_by(technical_key='sid').update(updated)
        session.commit()
