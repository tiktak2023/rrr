#!/usr/bin/python -tt
import pyodbc
from datetime import datetime
from dateutil import tz
from sqlalchemy import create_engine
from sqlalchemy.exc import IntegrityError
from sqlalchemy.exc import NoResultFound
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session

Base = automap_base()
new_gdat = "postgresql://gdat:z9RykV3c(FsI0@gdat_dev_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb"
# new_gdat = "postgresql://gdat:,X7SD_QFpg3a?5Sh@gdat_uat_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb"
engine = create_engine(new_gdat)

Base.prepare(engine, reflect=True)
technical_component = Base.classes.technical_component
technical_data = Base.classes.technical_data

conn = pyodbc.connect(
    "DRIVER=FreeTDS;SERVER=gdtuatdb01.fr.world.socgen;PORT=11030;DATABASE=gdat;UID=X194770;PWD=Ifeb0ctt;TDS_Version=5.0;"
)
# print("list_items:", list_items
cpt_not_found = 0


def add_to_db(list_obj):
    session = Session(engine)
    for obj in list_obj:
        session.add(obj)
        session.commit()


def insert_tech_data(data_old_gdat, obj_new_gdat):
    asm = "True" if row[1] else "False"  # 24 ko true fo 1 or 0 not ok
    oradbid = row[2] if row[2] else 0  # 23 ok
    nbconnection = row[3] if row[3] else 0  # 26 ko
    charset = row[4] if row[4] else ''  # 23 ok
    sid = row[5] if row[5] else ''  # 26 ko
    reserved_vol = row[6] if row[6] else 0  # 24 ko
    port = row[7]  # 27 ko
    db_unique_name = row[8] if row[8] else ''  # 24 ko
    used_vol = row[9] if row[9] else 0  # 24 ko
    role = "primary"  # 24 ko

    list_key_24 = [
        ("asm", asm),
        ("reserved_vol", reserved_vol),
        ("db_unique_name", db_unique_name),
        ("used_vol", used_vol),
        ("role", role),
    ]
    list_key_23 = [("oradbid", oradbid), ("charset", charset)]
    list_key_26 = [("nbconnection", nbconnection), ("sid", sid)]
    FRA = tz.gettz("Europe/Paris")
    data_input = {}
    data_input["last_modified"] = datetime.now().astimezone(tz=FRA)
    data_input["modified_by"] = "TAK11012023"
    data_input["component_uuid"] = obj_new_gdat.uuid
    list_obj = []
    print('obj_new_gdat.type_component_id:', obj_new_gdat.type_component_id)
    if obj_new_gdat.type_component_id == 24:
        for item in list_key_24:
            data_input["technical_key"] = item[0]
            data_input["technical_value"] = item[1]
            obj = technical_data(**data_input)
            list_obj.append(obj)

    elif obj_new_gdat.type_component_id == 23:
        for item in list_key_23:
            data_input["technical_key"] = item[0]
            data_input["technical_value"] = item[1]
            obj = technical_data(**data_input)
            list_obj.append(obj)

    elif obj_new_gdat.type_component_id == 26:
        for item in list_key_26:
            data_input["technical_key"] = item[0]
            data_input["technical_value"] = item[1]
            obj = technical_data(**data_input)
            list_obj.append(obj)

    elif obj_new_gdat.type_component_id == 27:
        if port:
            data_input["technical_key"] = "port"
            data_input["technical_value"] = port
            obj = technical_data(**data_input)
            list_obj.append(obj)

    print(" list_obj:", list_obj)
    return list_obj


with conn.cursor() as cur:
    # get all keys needed : ASM ==> ora_database SERVER.oraasm
    # Oradbid ==> ora_system SERVER.oradbid
    # Nb connexion ==> ora_instance
    # Charset ==> ora_system
    # SID ==> ora_instance ==> instance name
    # used volume==> ora_database
    # reserved volume==> ora_database
    # port ==> ora_listener
    # db_unique_name ==>ora_database SERVER.oradbname
    # role ==> primary ora_database#

    # req_sql = f""" select serverid , port, reserverd_vol, allocated_vol, used_vol, charset, nbconnection, nbsession  from dbo.SERVER s where  [type]!='mongodb'  """
    req_sql = f
    """ select serverid, oraasm as ASM, oradbid as Oradbid, nbconnection, charset, instance as SID,
                        reserverd_vol, port, oradbname, used_vol from dbo.SERVER s  where vendor='oracle' and type='cluster'"""

    res = cur.execute(req_sql)
    total = res.fetchall()
    total_empty = []
    # total = total[0]
    for row in total:
        with Session(engine) as session:
            try:
                obj_comp = session.query(technical_component).filter_by(id=row[0]).one()  # 23
                list_obj = insert_tech_data(row, obj_comp)
                add_to_db(list_obj)

                obj_comp = session.query(technical_component).filter_by(parent_component_id=obj_comp.uuid).one()  # 24
                list_obj = insert_tech_data(row, obj_comp)
                add_to_db(list_obj)

                obj_comp = session.query(technical_component).filter_by(parent_component_id=obj_comp.uuid).one()  # 26
                list_obj = insert_tech_data(row, obj_comp)
                add_to_db(list_obj)

                obj_comp = session.query(technical_component).filter_by(parent_component_id=obj_comp.uuid).one()  # 27
                list_obj = insert_tech_data(row, obj_comp)
                add_to_db(list_obj)

            except NoResultFound:
                print("id not found:", row[0])
                total_empty.append(row[0])
                continue

    print('total_empty:', total_empty)

# obj = technical_component(uuid=row[0], env_component_id=row[2], name=row[0], created_at=created_at, modified_at=last_modified, uuid=row[1], in_marley=row[2])
