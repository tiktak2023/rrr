#!/usr/bin/python -tt
import pyodbc
from datetime import datetime
from dateutil import tz
from sqlalchemy import create_engine
from sqlalchemy.exc import NoResultFound, IntegrityError
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session

Base = automap_base()
# new_gdat = "postgresql://gdat:c0BWMD5Eld,kyJM5Gl8@gdat_prod_db-gdt_5932_prd.fr.world.socgen:12400/gdatdb"
new_gdat = 'postgresql://gdat:z9RykV3c(FsI0@gdat_dev_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb'

engine = create_engine(new_gdat, pool_size=20, max_overflow=0)

Base.prepare(engine, reflect=True)
technical_component = Base.classes.technical_component
technical_data = Base.classes.technical_data
services = Base.classes.service
hosts = Base.classes.hosts
users = Base.classes.users

conn = pyodbc.connect(
    "DRIVER=FreeTDS;SERVER=gdtuatdb01.fr.world.socgen;PORT=11030;DATABASE=gdat;UID=X194770;PWD=Ifeb0ctt;TDS_Version=5.0;"
)


def get_id_dba():
    session = Session(engine)
    list_id = session.query(technical_component).filter_by(type_component_id=23).filter_by(arch_id=20).all()
    session.close()
    list_id = [obj.name_component for obj in list_id]
    list_id = tuple(list_id)
    return list_id


def get_all_dba():
    session = Session(engine)
    list_id = session.query(users).all()
    session.close()
    list_id = [obj.id for obj in list_id]
    list_id = tuple(list_id)
    return list_id


with conn.cursor() as cur:
    list_id = get_id_dba()
    users_id = get_all_dba()
    print('len list_id:', len(list_id))
    req_sql = f
    """SELECT
            p.dbaid,
            p.dbabkpid1,
            p.dbabkpid2,
            s.name
            FROM dbo.SERVER as s
            inner join dbo.SERVICE s2  on s.serviceid = s2.serviceid
            inner join [OBJECT] o on s.serverid = o.serverid
            inner join dbo.PROJECT_OBJECT po on po.objectid = o.objectid
            inner join dbo.PROJECT p  on po.projectid = p.projectid
            where s.vendor='oracle' and (s.xaas is not null or s.xaas !='1') and  s.name  not in {list_id}"""

    res = cur.execute(req_sql)
    total = res.fetchall()
    FRA = tz.gettz("Europe/Paris")
    print('len(total):', len(total))
    for row in total:
        ret = {'dba1': row[0],
               'dba2': row[1],
               'dba3': row[2],
               'modified_by': str(datetime.now().astimezone(tz=FRA)) + 'ocp_dba'}
        session = Session(engine)
        try:
            session.query(technical_component).filter_by(name_component=row[3]).update(ret)
            session.commit()
            session.close()
            # print('name:', row[3])
        except IntegrityError as e:
            print(e)
            continue
