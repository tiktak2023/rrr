#!/usr/bin/python -tt
import pyodbc
from datetime import datetime
from dateutil import tz
from sqlalchemy import create_engine
from sqlalchemy.exc import NoResultFound, IntegrityError
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session

Base = automap_base()
new_gdat_prd = "postgresql://gdat:c0BWMD5Eld,kyJM5Gl8@gdat_prod_db-gdt_5932_prd.fr.world.socgen:12400/gdatdb"
new_gdat = 'postgresql://gdat:z9RykV3c(FsI0@gdat_dev_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb'

engine = create_engine(new_gdat)
engine_prd = create_engine(new_gdat_prd)

Base.prepare(engine, reflect=True)
technical_component = Base.classes.technical_component
technical_data = Base.classes.technical_data
services = Base.classes.service
hosts = Base.classes.hosts
users = Base.classes

conn = pyodbc.connect(
    "DRIVER=FreeTDS;SERVER=gdtuatdb01.fr.world.socgen;PORT=11030;DATABASE=gdat;UID=X194770;PWD=Ifeb0ctt;TDS_Version=5.0;"
)


def insert_user(data_input):
    data_input = data_input
    obj = users(**data_input)
    session = Session(engine)
    session.add(obj)
    session.commit()


def set_user(id_user):
    session = Session(engine_prd)
    user_obj = session.query(users).filter_by(id=id_user).one()
    session.close()
    data_input = {'id': user_obj, 'email': user_obj.email, 'igg': user_obj.igg,
                  'active': user_obj.active, 'id_role': user_obj.id_role}
    insert_user(data_input)


def update_user():
    # session = Session(engine_prd)
    session = Session(engine)
    FRA = tz.gettz("Europe/Paris")
    val = str(datetime.now().astimezone(tz=FRA)) + 'set_dba'
    session = Session(engine)
    dt = '2020-12-02 17:14:57.477'
    dt = '2020-12-02'


    ret = session.query(technical_component).filter(technical_component.created_at > dt).all()
    print('ret:', ret[0].created_at)
    # session.query(technical_component).filter_by(type_component_id=23).filter_by(dba1=old).update(
    #     {'dba1': new, 'modified_by': val})
    # session.query(technical_component).filter_by(type_component_id=24).filter_by(dba1=old).update(
    #     {'dba1': new, 'modified_by': val})
    # session.query(technical_component).filter_by(type_component_id=25).filter_by(dba1=old).update(
    #     {'dba1': new, 'modified_by': val})
    # session.query(technical_component).filter_by(type_component_id=26).filter_by(dba1=old).update(
    #     {'dba1': new, 'modified_by': val})
    # session.query(technical_component).filter_by(type_component_id=27).filter_by(dba1=old).update(
    #     {'dba1': new, 'modified_by': val})
    # session.commit()


if __name__ == "__main__":
    # set_user(5001589)
    update_user()













