#!/usr/bin/python -tt
import pyodbc
from datetime import datetime
from dateutil import tz
from sqlalchemy import create_engine
from sqlalchemy.exc import IntegrityError, MultipleResultsFound
from sqlalchemy.exc import NoResultFound, IntegrityError
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session

Base = automap_base()
# new_gdat = "postgresql://gdat:,X7SD_QFpg3a?5Sh@gdat_uat_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb"
new_gdat = 'postgresql://gdat:z9RykV3c(FsI0@gdat_dev_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb'
engine = create_engine(new_gdat, pool_size=20, max_overflow=20)

Base.prepare(engine, reflect=True)
technical_component = Base.classes.technical_component
service = Base.classes.service
applications = Base.classes.application
users = Base.classes.users
technical_data = Base.classes.technical_data
services = Base.classes.service
hosts = Base.classes.hosts
service_host = Base.classes.service_host

list_td_all = []

list_users_not_found = []

list_app_not_found = []
service_id = None

list_not_user_app = []

list_host = []

list_app = []

list_app_multiple = []

list_not_app = []


def return_name_service(service_id):
    with Session(engine) as session:
        try:
            obj_comp = session.query(service).filter_by(id=service_id).one()
            return obj_comp.service_name
        except NoResultFound:
            return None


def check_compo(id_compo):
    try:
        session = Session(engine)
        ret = session.query(technical_component).filter_by(name_component=id_compo).all()
        session.close()
        return ret
    except NoResultFound:
        return None


def check_compo_id(id_compo):
    try:
        session = Session(engine)
        ret = session.query(technical_component).filter_by(id=id_compo).one()
        session.close()
        return ret
    except NoResultFound:
        return None


def check_service(service_data, name_service, name_domaine):
    """ Creation of a service """
    if service_data:
        try:
            session = Session(engine)
            session.query(services).filter_by(id=service_data).one()
            session.close()
            return None
        except NoResultFound:
            # list_service_not_found_mssql.append(row[7])
            session.close()
            service_name = name_service + "." + name_domaine
            # service_name = row[15] + '.' + row[16]
            last_modified = created_at = datetime.now().astimezone(tz=FRA)
            try:
                session = Session(engine)
                obj = session.query(services).filter_by(service_name=service_name).one()
                session.close()
                return obj.id, False
            except NoResultFound:

                service_input = {
                    "id": service_data,
                    "service_name": service_name,
                    "active": True,
                    "created_at": datetime.now().astimezone(tz=FRA),
                    "modified_at": datetime.now().astimezone(tz=FRA),
                    "modified_by": "03022023service_not_found",
                }
                obj = services(**service_input)
                session = Session(engine)
                session.add(obj)
                session.commit()
                return obj.id, True


def check_host_service(host_id, service_id):
    if host_id and service_id:
        try:
            session = Session(engine)
            session.query(service_host).filter_by(id_service=service_id). \
                filter_by(id_host=host_id).one()
            session.close()
            return None
        except NoResultFound:
            session.close()
            service_input = {"id_service": service_id, "id_host": host_id, "type_host": 17}
            obj = service_host(**service_input)
            session = Session(engine)
            session.add(obj)
            session.commit()
            return obj


def check_host(host_data):
    try:
        session = Session(engine)
        obj = session.query(hosts).filter_by(id=host_data).one()
        session.close()
        return obj
    except NoResultFound:
        session.close()
        return None


req_sql4 = f
"""SELECT s.serverid, h.name
	           FROM dbo.SERVER as s, dbo.HOST h   
	           where s.vendor='oracle' and s.[type] ='server' and s.hostid = h.hostid and s.serviceid = 0"""


def check_service_o0(total):
    for row in total:
        try:
            session = Session(engine)
            obj = session.query(services).filter_by(service_name=row[1]).one()
            session.expunge_all()
            session.close()
            print("service_id from found:", obj.id)
            return obj
        except NoResultFound as e:
            print("errror not found:", e)
            session.expunge_all()
            session.close()
            service_input = {
                "service_name": row[1],
                "active": True,
                "created_at": datetime.now().astimezone(tz=FRA),
                "modified_at": datetime.now().astimezone(tz=FRA),
                "modified_by": "02022023service_0_MAJRac",
            }
            obj = services(**service_input)
            session = Session(engine)
            try:
                session.add(obj)
                session.commit()
                print("service_id from not found:", obj.id)
                return obj
            except IntegrityError as e:
                print("e:----------->", e)
                print("total ---for service 0---->", total)
                session.expunge_all()
                session.close()
                print("serverid:", row[0])
                print("hostname:", row[1])


def insert_tech_data(
        asm,
        oradbid,
        nbconnection,
        charset,
        sid,
        reserved_vol,
        port,
        db_unique_name,
        used_vol,
        obj_new_gdat,
):
    asm = "True" if asm else "False"  # 24 ko true fo 1 or 0 not ok
    oradbid = oradbid if oradbid else 0  # 23 ok
    nbconnection = nbconnection if nbconnection else 0  # 26 ko
    charset = charset if charset else ""  # 23 ok
    sid = sid if sid else ""  # 26 ko
    reserved_vol = reserved_vol if reserved_vol else 0  # 24 ko
    port = port  # 27 ko
    db_unique_name = db_unique_name if db_unique_name else ""  # 24 ko
    used_vol = used_vol if used_vol else 0  # 24 ko
    role = "primary"  # 24 ko

    list_key_24 = [
        ("asm", asm),
        ("reserved_vol", reserved_vol),
        ("db_unique_name", db_unique_name),
        ("used_vol", used_vol),
        ("role", role),
    ]
    list_key_23 = [("oradbid", oradbid), ("charset", charset), ("ora_db_name",)]
    list_key_26 = [("nbconnection", nbconnection), ("sid", sid)]
    FRA = tz.gettz("Europe/Paris")
    list_objtd = []
    print("obj_new_gdat.type_component_id:", obj_new_gdat.type_component_id)
    if obj_new_gdat.type_component_id == 24:
        for item in list_key_24:
            data_input = {}
            data_input["last_modified"] = datetime.now().astimezone(tz=FRA)
            data_input["modified_by"] = "TAKAUTO13022023standalone_oracle"
            data_input["component_uuid"] = obj_new_gdat.uuid
            data_input["technical_key"] = item[0]
            data_input["technical_value"] = item[1]
            obj = technical_data(**data_input)
            list_objtd.append(obj)

    elif obj_new_gdat.type_component_id == 23:
        for item in list_key_23:
            data_input = {}
            data_input["last_modified"] = datetime.now().astimezone(tz=FRA)
            data_input["modified_by"] = "TAKAUTO13022023standalone_oracle"
            data_input["component_uuid"] = obj_new_gdat.uuid
            data_input["technical_key"] = item[0]
            data_input["technical_value"] = item[1]
            obj = technical_data(**data_input)
            list_objtd.append(obj)

    elif obj_new_gdat.type_component_id == 26:
        for item in list_key_26:
            data_input = {}
            data_input["last_modified"] = datetime.now().astimezone(tz=FRA)
            data_input["modified_by"] = "TAKAUTO13022023standalone_oracle"
            data_input["component_uuid"] = obj_new_gdat.uuid
            data_input["technical_key"] = item[0]
            data_input["technical_value"] = item[1]
            obj = technical_data(**data_input)
            list_objtd.append(obj)

    elif obj_new_gdat.type_component_id == 27:
        if port:
            data_input = {}
            data_input["last_modified"] = datetime.now().astimezone(tz=FRA)
            data_input["modified_by"] = "TAKAUTO13022023standalone_oracle"
            data_input["component_uuid"] = obj_new_gdat.uuid
            data_input["technical_key"] = "port"
            data_input["technical_value"] = port
            obj = technical_data(**data_input)
            list_objtd.append(obj)

    return list_objtd


req_sql = f
"""SELECT
   s.uuid4,
   s.xaas as arch_id,
   s.msp as management_type,
   s.purpose as env,
   s.name as name_compponent_ora_system,
   s.vendor as type_component,
   s.version as component_version,
   s.hostid as primary_host_id,
   s.serviceid as service_id,
   s.serverid as id,
   s.oradbname as name_component_ora_database,
   s.[instance] as name_component_ora_instance,
   s.ebf as ebf,
   s.serverid,
   s.reserverd_vol,
   s.allocated_vol,
   s.used_vol,
   s.port,
   s.oraasm as ASM, 
   s.oradbid as Oradbid, 
   s.charset,
   s.nbconnection
from SERVER s """

req_sql6 = f
""" (select serverid_source  from gdat.dbo.SERVER_LINK sl)"""
req_sql8 = f
""" and s.serverid not in (select serverid_target  from gdat.dbo.SERVER_LINK sl)"""

dic1 = {
    "charset": 20,
    "oradbid": 19,
    "oraasm": 18,
    "port": 17,
    "used_vol": 16,
    "allocated_vol": 15,
    "reserverd_vol": 14,
    "db_unique_name": 10,
    "sid": 11,
    "nbconnection": 21,
}

req_sql3 = f
""" SELECT
       s.uuid4, 
       s.xaas as arch_id,
       s.msp as management_type,
       s.purpose as env,
       s.name as name_compponent_ora_system,
       s.vendor as type_component,
       s.version as component_version,
       s.hostid as primary_host_id,
       s.serviceid as service_id,
       s.serverid as id,
       s.oradbname as name_component_ora_database,
       s.[instance] as name_component_ora_instance,
       s.ebf as ebf,
       s.serverid,
       p.iappliid,
       p.dbaid,
       p.dbabkpid1,
       p.dbabkpid2,
       s.charset,
       s.reserverd_vol,
       s.allocated_vol,
       s.used_vol,
       s.port,
       s.oraasm as ASM, 
       s.oradbid as Oradbid,
       s.nbconnection,
       s2.name,
       s2.domainname

from SERVER s
inner join dbo.SERVICE s2  on s.serviceid = s2.serviceid
inner join [OBJECT] o on s.serverid = o.serverid
inner join dbo.PROJECT_OBJECT po on po.objectid = o.objectid
inner join dbo.PROJECT p  on po.projectid = p.projectid
where p.iappliid is not null """

req_sql5 = f
""" SELECT
               s.uuid4, 
               s.xaas as arch_id,
               s.msp as management_type,
               s.purpose as env,
               s.name as name_compponent_ora_system,
               s.vendor as type_component,
               s.version as component_version,
               s.hostid as primary_host_id,
               s.serviceid as service_id,
               s.serverid as id,
               s.oradbname as name_component_ora_database,
               s.[instance] as name_component_ora_instance,
               s.ebf as ebf,
               s.serverid,
               p.iappliid,
               p.dbaid,
               p.dbabkpid1,
               p.dbabkpid2,
               s.charset,
               s.reserverd_vol,
               s.allocated_vol,
               s.used_vol,
               s.port,
               s.oraasm as ASM, 
               s.oradbid as Oradbid,
               s.nbconnection

            from SERVER s
            inner join [OBJECT] o on s.serverid = o.serverid
            inner join dbo.PROJECT_OBJECT po on po.objectid = o.objectid
            inner join dbo.PROJECT p  on po.projectid = p.projectid
            where p.iappliid is not null """

dic3 = {
    "charset": 20,
    "oradbid": 24,
    "oraasm": 23,
    "port": 22,
    "used_vol": 21,
    "allocated_vol": 20,
    "reserverd_vol": 19,
    "db_unique_name": 10,
    "sid": 11,
    "nbconnection": 25,
}

dic2 = {
    "charset": 20,
    "oradbid": 26,
    "oraasm": 25,
    "port": 24,
    "used_vol": 23,
    "allocated_vol": 22,
    "reserverd_vol": 21,
    "db_unique_name": 10,
    "sid": 11,
    "nbconnection": 27,
}


def check_iapplicode(data):
    if "-" in data:
        irt, trg = data.split("-")
        return irt, trg

    return int(data)


def check_users(user):
    session = Session(engine)
    if user:
        try:
            obj = session.query(users).filter_by(id=user).one()
            session.close()
            return obj.id
        except NoResultFound as e:
            print("user1 not found:", user)
            session.close()
            return None


def get_uuid_application(data):
    iapplicode = False
    if not '-' in str(data):
        if isinstance(int(data), int):
            iapplicode = data
    else:
        data = data.split('-')
        irt, trg = data[0], data[1]

    # session = Session(engine)
    if iapplicode:
        try:
            session = Session(engine)
            ret = (
                session.query(applications).filter_by(iapplicode=str(iapplicode)).one()
            )
            session.close()
            return ret.uuid
        except NoResultFound as e:
            list_app.append(iapplicode)
            # list_not_found.append(iapplicode)
            session.close()
            return

        except MultipleResultsFound:
            list_app_multiple.append(iapplicode)
            session = Session(engine)
            ret = (
                session.query(applications).filter_by(iapplicode=str(iapplicode)).all()
            )
            session.close()
            return ret[0].uuid
            # list_multi.append(iapplicode)
    else:
        try:
            session = Session(engine)
            ret = (
                session.query(applications)
                    .filter_by(irt=irt)
                    .filter_by(trigram=trg)
                    .one()
            )
            session.close()
            return ret.uuid
        except NoResultFound as e:
            session.close()
            return
        except MultipleResultsFound as e:
            session = Session(engine)
            ret = (
                session.query(applications)
                    .filter_by(irt=irt)
                    .filter_by(trigram=trg)
                    .all()
            )
            session.close()
            return ret[0].uuid
            # list_not_found.append(iapplicode)


conn = pyodbc.connect(
    "DRIVER=FreeTDS;SERVER=gdtuatdb01.fr.world.socgen;PORT=11030;DATABASE=gdat;UID=X194770;PWD=Ifeb0ctt;TDS_Version=5.0;"
)
list_obj = []
list_source = []
oradb = False
list_comp_not_inserted = []
list_with_one_ora = []
list_many_ora_inst = []
list_ora_db = []
req_sql7 = f
""" and (s.xaas is null or s.xaas ='1')  and s.type = 'server' and s.vendor='oracle' and s.serverid not in """
list_cmp_duplicate = []
list_empty_name = []
list_duplicate = []
no_instance_list = []
no_db_instance = []
no_dbname = []
existe_name_compo = []
existe_id_compo = []
with conn.cursor() as cur:
    req_sql = req_sql3 + req_sql7 + req_sql6 + req_sql8
    print('req_sql:', req_sql)
    res = cur.execute(req_sql)
    print('res:', res)

    total = res.fetchall()
    print('total:', total)
    FRA = tz.gettz("Europe/Paris")

    print('len total:', len(total))
    for row in total:
        set_id = False
        if not row[4]:
            list_empty_name.append(row[9])
            continue

        if not row[10]:
            ret = check_compo(row[4])
            if ret:
                for obj in ret:
                    session = Session(engine)
                    res = session.query(technical_component).filter_by(parent_component_id=obj.uuid).all()
                    if not res:
                        session.query(technical_data).filter_by(component_uuid=obj.uuid).delete()
                        session.commit()
                        session = Session(engine)
                        session.query(technical_component).filter_by(id=obj.id).delete()
                        session.commit()
            no_dbname.append(row[9])
            row[10] = row[11]

        if check_compo(row[4]):
            existe_name_compo.append(row[9])
            continue

        if check_compo_id(row[9]):
            existe_id_compo.append(row[4])
            set_id = True
            # continue

        if row[4] in list_cmp_duplicate:
            list_duplicate.append(row[9])
            continue

        list_cmp_duplicate.append(row[4])
        print('row[14]:', row[14])
        app_uuid = get_uuid_application(row[14])
        print('app_uuid:-------->', app_uuid)
        user1 = check_users(row[15])
        user2 = check_users(row[16])
        user3 = check_users(row[17])

        if not user1 or not user2 or not user3 or not app_uuid:
            if not user1:
                list_not_user_app.append(row[9])
            if not user2:
                list_not_user_app.append(row[9])
            if not user3:
                list_not_user_app.append(row[9])

            if not app_uuid:
                list_not_app.append(row[9])

        last_modified = created_at = datetime.now().astimezone(tz=FRA)
        data_input = {}
        data_input["application_id"] = app_uuid
        data_input["dba1"] = user1
        data_input["dba2"] = user2
        data_input["dba3"] = user3
        data_input["arch_id"] = 20
        data_input["management_type_id"] = 8
        data_input["ebf"] = row[12]

        # ret = check_service(row[8], row[26], row[27])
        ret = check_service(row[8], row[26], row[27])
        print('ret check_service:', ret)
        host_id = check_host(row[7])
        if not host_id:
            list_host.append(row[7])
            print('host_id not found', row[7])
            continue
            # continue
        if ret:
            row[8] = ret[0]
            if ret[1]:
                host_id = check_host(row[7])
                print('host_id:---------->', host_id)
                if host_id:
                    res1 = check_host_service(row[7], row[8])
                    print('res1------------>:', res1)
                else:
                    list_host.append(row[7])
                    continue
        elif host_id:
            res2 = check_host_service(row[7], row[8])
            print('res2------------>:', res2)

        # data_input["name_component"] = row[10] if row[10] else row[11]
        data_input["name_component"] = row[4]
        # if set_id:
        data_input["id"] = row[9]
        data_input["type_component_id"] = 23
        data_input["component_version"] = row[6]
        data_input["primary_host_id"] = row[7]
        # data_input["service_id"] = row[8] if row[8] else None
        data_input["last_modified"] = datetime.now().astimezone(tz=FRA)
        data_input["created_at"] = datetime.now().astimezone(tz=FRA)
        if "devel" in row[3]:
            data_input["env_component_id"] = 5
        if "prod" in row[3]:
            data_input["env_component_id"] = 7

        if "dr" in row[3]:
            data_input["env_component_id"] = 19
        if "uat" in row[3]:
            data_input["env_component_id"] = 6

        if not row[0]:
            import uuid

            res_uuid = getattr(uuid, "uuid4")
            row[0] = res_uuid()
        data_input["uuid"] = row[0]
        data_input["modified_by"] = "TAKAUTO13022023standalone_oracle"

        if set_id:
            data_input.pop('id')

        obj = technical_component(**data_input)  # Add ora_systeme
        list_obj.append(obj)
        if not set_id:
            data_input.pop('id')
        list_duplicate.append(row[4])

        dic3 = {
            "charset": 20,
            "oradbid": 24,
            "oraasm": 23,
            "port": 22,
            "used_vol": 21,
            "allocated_vol": 20,
            "reserverd_vol": 19,
            "db_unique_name": 10,
            "sid": 11,
            "nbconnection": 25,
        }

        asm = row[23]
        oradbid = row[24]
        charset = row[18]
        sid = row[11]
        reserved_vol = row[19]
        port = row[22]
        db_unique_name = row[10]
        used_vol = row[21]
        allocated_vol = row[20]
        nbconnection = row[25]

        ltd_23 = insert_tech_data(
            asm=asm,
            oradbid=oradbid,
            nbconnection=nbconnection,
            charset=charset,
            sid=sid,
            reserved_vol=reserved_vol,
            port=port,
            db_unique_name=db_unique_name,
            used_vol=used_vol,
            obj_new_gdat=obj,
        )
        list_td_all.append(ltd_23)
        # if row[10] in list_cmp_duplicate:
        #     continue

        if not row[10]:
            no_dbname.append(row[9])
            continue

        data_input["name_component"] = row[10]
        data_input["type_component_id"] = 24

        data_input["parent_component_id"] = data_input["uuid"]
        import uuid

        res_uuid = getattr(uuid, "uuid4")
        data_input["uuid"] = res_uuid()

        obj = technical_component(**data_input)

        dic3 = {
            "charset": 18,
            "oradbid": 24,
            "oraasm": 23,
            "port": 22,
            "used_vol": 21,
            "allocated_vol": 20,
            "reserverd_vol": 19,
            "db_unique_name": 10,
            "sid": 11,
            "nbconnection": 25,
        }

        asm = row[23]
        oradbid = row[24]
        charset = row[18]
        print('charset:------------>', charset)
        sid = row[11]
        reserved_vol = row[19]
        port = row[22]
        db_unique_name = row[10]
        used_vol = row[21]
        allocated_vol = row[20]
        nbconnection = row[25]

        ltd_24 = insert_tech_data(
            asm=asm,
            oradbid=oradbid,
            nbconnection=nbconnection,
            charset=charset,
            sid=sid,
            reserved_vol=reserved_vol,
            port=port,
            db_unique_name=db_unique_name,
            used_vol=used_vol,
            obj_new_gdat=obj,
        )
        # ltd_24 = insert_tech_data(db[0], obj)
        list_td_all.append(ltd_24)
        list_obj.append(obj)

        if not row[11]:
            no_db_instance.append(row[9])
            continue

        data_input["name_component"] = row[11]
        data_input["type_component_id"] = 26
        data_input["service_id"] = row[8] if row[8] else None
        data_input["service_id"] = row[8] if row[8] else None
        data_input["parent_component_id"] = data_input["uuid"]

        import uuid

        res_uuid = getattr(uuid, "uuid4")
        data_input["uuid"] = res_uuid()
        obj = technical_component(**data_input)
        ltd_26 = insert_tech_data(
            asm=asm,
            oradbid=oradbid,
            nbconnection=nbconnection,
            charset=charset,
            sid=sid,
            reserved_vol=reserved_vol,
            port=port,
            db_unique_name=db_unique_name,
            used_vol=used_vol,
            obj_new_gdat=obj,
        )
        list_td_all.append(ltd_26)

        list_obj.append(obj)  # Add ora_instance

        # if service_name:
        service_name = return_name_service(row[8])

        data_input["name_component"] = service_name if service_name else "default"
        data_input["type_component_id"] = 27
        data_input["parent_component_id"] = data_input["uuid"]

        import uuid

        res_uuid = getattr(uuid, "uuid4")
        data_input["uuid"] = res_uuid()
        obj = technical_component(**data_input)
        ltd_27 = insert_tech_data(
            asm=asm,
            oradbid=oradbid,
            nbconnection=nbconnection,
            charset=charset,
            sid=sid,
            reserved_vol=reserved_vol,
            port=port,
            db_unique_name=db_unique_name,
            used_vol=used_vol,
            obj_new_gdat=obj,
        )
        list_td_all.append(ltd_27)
        list_obj.append(obj)  # Add ora_listener

    # existe_name_compo

    print('existe_name_compo:---->', existe_name_compo)
    print('len(existe_name_compo):---->', len(existe_name_compo))

    print('existe_id_compo:---->', existe_id_compo)
    print('len(existe_id_compo):---->', len(existe_id_compo))

    print('list_empty_name:---->', list_empty_name)
    print('len(list_empty_name):---->', len(list_empty_name))

    print('list_duplicate:---->', list_duplicate)
    print('len(list_duplicate):---->', len(list_duplicate))

    print('no_instance_list:---->', no_instance_list)
    print('len(no_instance_list):---->', len(no_instance_list))

    print('no_db_instance:---->', no_db_instance)
    print('len(no_db_instance):---->', len(no_db_instance))
    #
    print('no_dbname:---->', no_dbname)
    print('len(no_dbname):---->', len(no_dbname))
    # list_app_multiple
    print('list_app:---->', list_app)
    print('len(list_app):---->', len(list_app))

    print('list_app_multiple:---->', list_app_multiple)
    print('len(list_app_multiple):---->', len(list_app_multiple))

    print('total element:', len(list_obj))
    session = Session(engine)
    session.bulk_save_objects(list_obj)
    session.commit()

    list_tds_all = [j for i in list_td_all for j in i]
    print('list_host:', list_host)
    session = Session(engine)
    session.bulk_save_objects(list_tds_all)
    session.commit()
