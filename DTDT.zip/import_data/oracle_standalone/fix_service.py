#!/usr/bin/python -tt
import pyodbc
from datetime import datetime
from dateutil import tz
from sqlalchemy import create_engine
from sqlalchemy.exc import IntegrityError, MultipleResultsFound
from sqlalchemy.exc import NoResultFound, IntegrityError
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session

Base = automap_base()
new_gdat = "postgresql://gdat:,X7SD_QFpg3a?5Sh@gdat_uat_db-gdt_5932_dev.fr.world.socgen:12400/gdatdb"
engine = create_engine(new_gdat, pool_size=20, max_overflow=0)

Base.prepare(engine, reflect=True)
technical_component = Base.classes.technical_component
service = Base.classes.service
applications = Base.classes.application
users = Base.classes.users
technical_data = Base.classes.technical_data
services = Base.classes.service
hosts = Base.classes.hosts
service_host = Base.classes.service_host

list_td_all = []

list_users_not_found = []

list_app_not_found = []
service_id = None

list_not_inserted = []


def check_service(service_data, name_service, name_domaine, list_name):
    if service_data:
        # try:
        #     session = Session(engine)
        #     session.query(services).filter_by(id=service_data).one()
        #     session.close()
        #     return None
        # except NoResultFound:
        # list_service_not_found_mssql.append(row[7])
        service_name = name_service + "." + name_domaine
        # service_name = row[15] + '.' + row[16]
        last_modified = created_at = datetime.now().astimezone(tz=FRA)

        if service_name not in list_name:
            service_input = {
                "id": service_data,
                "service_name": service_name,
                "active": True,
                "created_at": datetime.now().astimezone(tz=FRA),
                "modified_at": datetime.now().astimezone(tz=FRA),
                "modified_by": "03022023service_not_found",
            }
            obj = services(**service_input)
            # list_service.append(obj)
            # session = Session(engine)
            # session.add(obj)
            # session.commit()
            return obj, True
        else:
            return False

            # try:
            #     session = Session(engine)
            #     obj = session.query(services).filter_by(service_name=service_name).one()
            #     session.close()
            #     return obj.id, False
            # except NoResultFound:
            #
            #     service_input = {
            #         "id": service_data,
            #         "service_name": service_name,
            #         "active": True,
            #         "created_at": datetime.now().astimezone(tz=FRA),
            #         "modified_at": datetime.now().astimezone(tz=FRA),
            #         "modified_by": "03022023service_not_found",
            #     }
            #     obj = services(**service_input)
            #     list_service.append(obj)
            #     # session = Session(engine)
            #     # session.add(obj)
            #     # session.commit()
            #     return obj.id, True
            # service_name = row[15] + '.' + row[16]
            # last_modified = created_at = datetime.now().astimezone(tz=FRA)
            # try:
            #     session = Session(engine)
            #     obj = session.query(services).filter_by(service_name=service_name).one()
            #     session.close()
            #     return obj.id, False
            # except NoResultFound:
            #     session.close()
            #     service_input = {
            #         "id": service_data,
            #         "service_name": service_name,
            #         "active": True,
            #         "created_at": datetime.now().astimezone(tz=FRA),
            #         "modified_at": datetime.now().astimezone(tz=FRA),
            #         "modified_by": "03022023service_not_foundStandalone",
            #     }
            #     obj = services(**service_input)
            #     list_service.append(obj)
            #     # session = Session(engine)
            #     # session.add(obj)
            #     # session.commit()
            #     return obj.id, True


req_sql3 = f
""" SELECT
       s.uuid4, 
       s.xaas as arch_id,
       s.msp as management_type,
       s.purpose as env,
       s.name as name_compponent_ora_system,
       s.vendor as type_component,
       s.version as component_version,
       s.hostid as primary_host_id,
       s.serviceid as service_id,
       s.serverid as id,
       s.oradbname as name_component_ora_database,
       s.[instance] as name_component_ora_instance,
       s.ebf as ebf,
       s.serverid,
       p.iappliid,
       p.dbaid,
       p.dbabkpid1,
       p.dbabkpid2,
       s.charset,
       s.reserverd_vol,
       s.allocated_vol,
       s.used_vol,
       s.port,
       s.oraasm as ASM, 
       s.oradbid as Oradbid,
       s.nbconnection,
       s2.name,
       s2.domainname

from SERVER s
inner join dbo.SERVICE s2  on s.serviceid = s2.serviceid
inner join [OBJECT] o on s.serverid = o.serverid
inner join dbo.PROJECT_OBJECT po on po.objectid = o.objectid
inner join dbo.PROJECT p  on po.projectid = p.projectid
where p.iappliid is not null  """


def check_host(host_data):
    try:
        session = Session(engine)
        session.query(hosts).filter_by(id=host_data).one()
        session.close()
        return True
    except NoResultFound:
        session.close()
        return None


def check_host_service(host_id, service_id):
    if host_id and service_id:
        service_input = {"id_service": service_id, "id_host": host_id, "type_host": 17}
        obj = service_host(**service_input)
        list_host_service.append((obj))
        # session = Session(engine)
        # session.add(obj)
        # session.commit()


conn = pyodbc.connect(
    "DRIVER=FreeTDS;SERVER=gdtuatdb01.fr.world.socgen;PORT=11030;DATABASE=gdat;UID=X194770;PWD=Ifeb0ctt;TDS_Version=5.0;"
)
list_host_service = []
list_service = []

session = Session(engine)
list_all = session.query(services).all()
session.close()
list_id = [obj.id for obj in list_all]
list_id = tuple(list_id)

list_name = [obj.service_name for obj in list_all]
list_name_no_duplicate = []
with conn.cursor() as cur:
    req_sql = req_sql3 + f
    """ and s.serviceid not in {list_id} """
    res = cur.execute(req_sql)
    total = res.fetchall()
    FRA = tz.gettz("Europe/Paris")

    for row in total:
        if row[8] not in list_id:
            ret = check_service(row[8], row[26], row[27], list_name)
            if ret:
                if ret[0].service_name not in list_name_no_duplicate:  # R
                    list_service.append(ret[0])
                    list_name_no_duplicate.append(ret[0].service_name)
                    # if ret[0].service_name in
                    # list_service.append(ret[0])

                    # if ret[0].id == row[8]:
                    #     list_service.append(ret[0])
                    # if ret:
                    #     row[8] = ret[0]
                    #     if ret[1]:
                    #         host_id = check_host(row[7])
                    #         if host_id:
                    #             check_host_service(row[7], row[8])

# print('list_id:', list_id)
list_name = [obj.service_name for obj in list_service]
print('nom de service:', list_name)
session = Session(engine)
session.bulk_save_objects(list_service)
session.commit()


# session = Session(engine)
# session.bulk_save_objects(list_host_service)



# session.commit()
